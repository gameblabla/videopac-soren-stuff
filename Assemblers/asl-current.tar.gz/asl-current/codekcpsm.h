/* codekcpsm.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator xilinx kcpsm                                                */
/*                                                                           */
/* Historie: 27.02.2003 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/
/* $Id: codekcpsm.h,v 1.1 2003/11/06 02:49:23 alfred Exp $                  */
/*****************************************************************************
 * $Log: codekcpsm.h,v $
 * Revision 1.1  2003/11/06 02:49:23  alfred
 * - recreated
 *
 * Revision 1.1  2003/03/09 10:28:28  alfred
 * - added KCPSM
 *
 *****************************************************************************/

extern void codekcpsm_init(void);
