#ifndef _CODE807X_H
#define _CODE807X_H
/* codescmp.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator National INS807x                                            */
/*                                                                           */
/*****************************************************************************/
/* $Id: code807x.h,v 1.1 2003/11/06 02:49:22 alfred Exp $                   *
 *****************************************************************************
 * $Log: code807x.h,v $
 * Revision 1.1  2003/11/06 02:49:22  alfred
 * - recreated
 *
 * Revision 1.1  2003/03/16 18:53:43  alfred
 * - created 807x
 *
 *****************************************************************************/

extern void code807x_init(void);
#endif /* _CODE807X_H */
