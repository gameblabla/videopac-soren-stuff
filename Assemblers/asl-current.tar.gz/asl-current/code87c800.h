#ifndef _CODE87C800_H
#define _CODE87C800_H
/* code87c800.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator TLCS-870                                                    */
/*                                                                           */
/* Historie: 29.12.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code87c800_init(void);
#endif /* _CODE87C800_H */
