#ifndef _CODE8008_H
#define _CODE8008_H
/* code8008.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator Intel 8008                                                  */
/*                                                                           */
/* Historie: 3.12.1997 Grundsteinlegung                                      */
/*                                                                           */
/*****************************************************************************/

extern void code8008_init(void);
#endif /* _CODE8008_H */
