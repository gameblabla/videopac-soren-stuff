#ifndef _CODE51_H
#define _CODE51_H
/* code51.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator fuer MCS-51/252 Prozessoren                                 */
/*                                                                           */
/* Historie:  5. 6.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code51_init(void);
#endif /* _CODE51_H */
