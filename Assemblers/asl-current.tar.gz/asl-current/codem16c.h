#ifndef _CODEM16C_H
#define _CODEM16C_H
/* codem16c.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator M16C                                                        */
/*                                                                           */
/* Historie: 17.12.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void codem16c_init(void);
#endif /* _CODEM16C_H */
