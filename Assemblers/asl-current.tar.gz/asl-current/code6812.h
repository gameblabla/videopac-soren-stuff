#ifndef _CODE6812_H
#define _CODE6812_H
/* code6812.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegeneratormodul CPU12                                                  */
/*                                                                           */
/* Historie: 13.10.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code6812_init(void);
#endif /* _CODE6812_H */
