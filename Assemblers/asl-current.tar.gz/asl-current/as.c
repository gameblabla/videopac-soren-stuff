/* as.c */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Hauptmodul                                                                */
/*                                                                           */
/*****************************************************************************/

#include "stdinc.h"
#include <string.h>
#include <ctype.h>
#include <setjmp.h>
#include <assert.h>

#include "version.h"
#include "endian.h"
#include "bpemu.h"

#include "stdhandl.h"
#include "nls.h"
#include "nlmessages.h"
#include "as.rsc"
#include "ioerrs.h"
#include "strutil.h"
#include "stringlists.h"
#include "cmdarg.h"
#include "asmitree.h"
#include "trees.h"
#include "chunks.h"
#include "asminclist.h"
#include "asmfnums.h"
#include "asmdef.h"
#include "cpulist.h"
#include "errmsg.h"
#include "asmsub.h"
#include "asmpars.h"
#include "asmmac.h"
#include "asmstructs.h"
#include "asmif.h"
#include "asmcode.h"
#include "asmdebug.h"
#include "asmrelocs.h"
#include "asmallg.h"
#include "codepseudo.h"
#include "as.h"

#include "code68k.h"
#include "code56k.h"
#include "code601.h"
#include "codemcore.h"
#include "codexgate.h"
#include "code68.h"
#include "code6805.h"
#include "code6809.h"
#include "code6812.h"
#include "codes12z.h"
#include "code6816.h"
#include "code68rs08.h"
#include "codeh8_3.h"
#include "codeh8_5.h"
#include "code7000.h"
#include "code65.h"
#include "codeh16.h"
#include "code7700.h"
#include "codehmcs400.h"
#include "code4500.h"
#include "codem16.h"
#include "codem16c.h"
#include "code4004.h"
#include "code8008.h"
#include "code48.h"
#include "code51.h"
#include "code96.h"
#include "code85.h"
#include "code86.h"
#include "code960.h"
#include "code8x30x.h"
#include "code2650.h"
#include "codexa.h"
#include "codeavr.h"
#include "code29k.h"
#include "code166.h"
#include "codez80.h"
#include "codez8.h"
#include "codekcpsm.h"
#include "codekcp3.h"
#include "codemic8.h"
#include "code96c141.h"
#include "code90c141.h"
#include "code87c800.h"
#include "code870c.h"
#include "code47c00.h"
#include "code97c241.h"
#include "code9331.h"
#include "code16c5x.h"
#include "code16c8x.h"
#include "code17c4x.h"
#include "codesx20.h"
#include "codest6.h"
#include "codest7.h"
#include "codest9.h"
#include "code6804.h"
#include "code3201x.h"
#include "code3202x.h"
#include "code3203x.h"
#include "code3205x.h"
#include "code3254x.h"
#include "code3206x.h"
#include "code9900.h"
#include "codetms7.h"
#include "code370.h"
#include "codemsp.h"
#include "codetms1.h"
#include "codescmp.h"
#include "code807x.h"
#include "codecop4.h"
#include "codecop8.h"
#include "codesc14xxx.h"
#include "codeace.h"
#include "codef8.h"
#include "code78c10.h"
#include "code75xx.h"
#include "code75k0.h"
#include "code78k0.h"
#include "code78k2.h"
#include "code78k3.h"
#include "code78k4.h"
#include "code7720.h"
#include "code77230.h"
#include "code53c8xx.h"
#include "codefmc8.h"
#include "codefmc16.h"
#include "codeol40.h"
#include "codeol50.h"
#include "code1802.h"
#include "codevector.h"
#include "codexcore.h"
#include "code1750.h"
/**          Code21xx};**/

static char *FileMask;
static long StartTime, StopTime;
static Boolean GlobErrFlag;
static Boolean MasterFile;
static Boolean WasIF, WasMACRO;
static unsigned MacroNestLevel = 0;

/*=== Zeilen einlesen ======================================================*/


#if 0
# define dbgentry(str) printf("***enter %s\n", str);
# define dbgexit(str) printf("***exit %s\n", str);
#else
# define dbgentry(str) {}
# define dbgexit(str) {}
#endif

static void NULL_Restorer(PInputTag PInp)
{
  UNUSED(PInp);
}

static Boolean NULL_GetPos(PInputTag PInp, char *dest)
{
  UNUSED(PInp);

  *dest = '\0';
  return False;
}

static Boolean INCLUDE_Processor(PInputTag PInp, char *Erg);

static PInputTag GenerateProcessor(void)
{
  PInputTag PInp = malloc(sizeof(TInputTag));

  PInp->IsMacro = False;
  PInp->Next = NULL;
  PInp->First = True;
  PInp->OrigDoLst = DoLst;
  PInp->StartLine = CurrLine;
  PInp->ParCnt = 0; PInp->ParZ = 0;
  InitStringList(&(PInp->Params));
  PInp->LineCnt = 0; PInp->LineZ = 1;
  PInp->Lines = PInp->LineRun = NULL;
  StrCompMkTemp(&PInp->SpecName, PInp->SpecNameStr);
  StrCompReset(&PInp->SpecName);
  PInp->AllArgs[0] = '\0';
  PInp->NumArgs[0] = '\0';
  PInp->IsEmpty = False;
  PInp->Buffer = NULL;
  PInp->Datei = NULL;
  PInp->IfLevel = SaveIFs();
  PInp->Restorer = NULL_Restorer;
  PInp->GetPos = NULL_GetPos;
  PInp->Macro = NULL;
  PInp->SaveAttr[0] = '\0';
  PInp->SaveLabel[0] = '\0';
  PInp->GlobalSymbols = False;
  PInp->UsesNumArgs =
  PInp->UsesAllArgs = False;

  /* in case the input tag chain is empty, this must be the master file */

  PInp->FromFile = (!FirstInputTag) || (FirstInputTag->Processor == INCLUDE_Processor);

  return PInp;
}

static POutputTag GenerateOUTProcessor(SimpProc Processor, tErrorNum OpenErrMsg)
{
  POutputTag POut;

  POut = (POutputTag) malloc(sizeof(TOutputTag));
  POut->Processor = Processor;
  POut->NestLevel = 0;
  POut->Tag = NULL;
  POut->Mac = NULL;
  POut->ParamNames = NULL;
  POut->ParamDefVals = NULL;
  POut->PubSect = 0;
  POut->GlobSect = 0;
  POut->DoExport = False;
  POut->DoGlobCopy= False;
  POut->UsesNumArgs =
  POut->UsesAllArgs = False;
  *POut->GName = '\0';
  POut->OpenErrMsg = OpenErrMsg;

  return POut;
}

/*=========================================================================*/
/* Listing erzeugen */

static void MakeList_Gen2Line(char *pDest, unsigned DestLen, Word EffLen, Word *n)
{
  int z, Rest;
  char Str[20];

  Rest = EffLen - (*n);
  if (Rest > 8)
    Rest = 8;
  if (DontPrint)
    Rest = 0;
  for (z = 0; z < (Rest >> 1); z++)
  {
    HexString(Str, sizeof(Str), WAsmCode[(*n) >> 1], 4);
    strmaxcat(pDest, Str, DestLen);
    strmaxcat(pDest, " ", DestLen);
    (*n) += 2;
  }
  if (Rest & 1)
  {
    HexString(Str, sizeof(Str), BAsmCode[*n], 2);
    strmaxcat(pDest, Str, DestLen);
    strmaxcat(pDest, "   ", DestLen);
    (*n)++;
  }
  for (z = 1; z <= (8 - Rest) >> 1; z++)
    strmaxcat(pDest, "     ", DestLen);
}

static void MakeList_Gen4Line(char *pDest, unsigned DestLen, Word EffLen, Word *n)
{
  int z, Rest, wr = 0;
  char Str[20];

  Rest = EffLen - (*n);
  if (Rest > 8)
    Rest = 8;
  if (DontPrint)
    Rest = 0;
  for (z = 0; z < (Rest >> 2); z++)
  {
    HexString(Str, sizeof(Str), DAsmCode[(*n) >> 2], 8);
    strmaxcat(pDest, Str, DestLen);
    strmaxcat(pDest, " ", DestLen);
    *n += 4;
    wr += 9;
  }
  for (z = 0; z < (Rest&3); z++)
  {
    HexString(Str, sizeof(Str), BAsmCode[(*n)++], 2);
    strmaxcat(pDest, Str, DestLen);
    strmaxcat(pDest, " ", DestLen);
    wr += 3;
  }
  strmaxcat(pDest, Blanks(20 - wr), DestLen);
}

static void MakeList(void)
{
  String h, h2, h3, Tmp;
  Word i, k;
  Word n, EffLen;
  Boolean ThisDoLst;

  EffLen = CodeLen * Granularity();

#if 0
  fprintf(stderr, "[%s] WasIF %u WasMACRO %u DoLst %u\n", OpPart.Str, WasIF, WasMACRO, DoLst);
#endif
  if (WasIF)
    ThisDoLst = !!(DoLst & eLstMacroExpIf);
  else if (WasMACRO)
    ThisDoLst = !!(DoLst & eLstMacroExpMacro);
  else
  {
    if (!IfAsm && (!(DoLst & eLstMacroExpIf)))
      ThisDoLst = False;
    else
      ThisDoLst = !!(DoLst & eLstMacroExpRest);
  }

  if ((!ListToNull) && (ThisDoLst) && ((ListMask & 1) != 0) && (!IFListMask()))
  {
    /* Zeilennummer / Programmzaehleradresse: */

    if (IncDepth == 0)
      strmaxcpy(h2, "   ", sizeof(h));
    else
    {
      sprintf(Tmp, IntegerFormat, IncDepth);
      as_snprintf(h2, sizeof(h2), "(%s)", Tmp);
    }
    if (ListMask & ListMask_LineNums)
    {
      sprintf(h3, Integ32Format, CurrLine);
      as_snprintf(h, sizeof(h), "%5s/", h3);
      strmaxcat(h2, h, sizeof(h));
    }
    strmaxcpy(h, h2, sizeof(h));
    HexBlankString(h2, sizeof(h2), EProgCounter() - CodeLen, 8);
    strmaxcat(h, h2, sizeof(h));
    strmaxcat(h, Retracted?" R ":" : ", sizeof(h));

    /* Extrawurst in Listing ? */

    if (*ListLine != '\0')
    {
      strmaxcat(h, ListLine, sizeof(h));
      strmaxcat(h, Blanks(20 - strlen(ListLine)), sizeof(h));
      strmaxcat(h, OneLine, sizeof(h));
      WrLstLine(h);
      *ListLine = '\0';
    }

    /* Code ausgeben */

    else
    {
      switch (ActListGran)
      {
        case 4:
          n = 0;
          MakeList_Gen4Line(h, sizeof(h), EffLen, &n);
          strmaxcat(h, OneLine, sizeof(h)); WrLstLine(h);
          if (!DontPrint)
          {
            while (n < EffLen)
            {
              strmaxcpy(h, "                    ", sizeof(h));
              MakeList_Gen4Line(h, sizeof(h), EffLen, &n);
              WrLstLine(h);
            }
          }
          break;
        case 2:
          n = 0;
          MakeList_Gen2Line(h, sizeof(h), EffLen, &n);
          strmaxcat(h, OneLine, sizeof(h)); WrLstLine(h);
          if (!DontPrint)
          {
            while (n < EffLen)
            {
              strmaxcpy(h, "                    ", sizeof(h));
              MakeList_Gen2Line(h, sizeof(h), EffLen, &n);
              WrLstLine(h);
            }
          }
          break;
        default:
        {
          char Str[20];

          if ((TurnWords) && (Granularity() != ActListGran))
            DreheCodes();
          for (i = 0; i < 6; i++)
            if ((!DontPrint) && (EffLen > i))
            {
              HexString(Str, sizeof(Str), BAsmCode[i], 2);
              strmaxcat(h, Str, sizeof(h));
              strmaxcat(h, " ", sizeof(h));
            }
            else
              strmaxcat(h, "   ", sizeof(h));
          strmaxcat(h, "  ", sizeof(h));
          strmaxcat(h, OneLine, sizeof(h));
          WrLstLine(h);
          if ((EffLen > 6) && (!DontPrint))
          {
            EffLen -= 6;
            n = EffLen / 6;
            if ((EffLen % 6) == 0)
              n--;
            for (i = 0; i <= n; i++)
            {
              strmaxcpy(h, "              ", sizeof(h));
              if (ListMask & ListMask_LineNums)
                strmaxcat(h, "      ", sizeof(h));
              for (k = 0; k < 6; k++)
                if (EffLen > i * 6 + k)
                {
                  HexString(Str, sizeof(Str), BAsmCode[i * 6 + k + 6], 2);
                  strmaxcat(h, Str, sizeof(h));
                  strmaxcat(h, " ", sizeof(h));
                }
               WrLstLine(h);
            }
          }
          if ((TurnWords) && (Granularity() != ActListGran))
            DreheCodes();
        }
      }
    }
  }
}

/*=========================================================================*/
/* Makroprozessor */

/*-------------------------------------------------------------------------*/
/* allgemein gebrauchte Subfunktionen */

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* werden gebraucht, um festzustellen, ob innerhalb eines Makrorumpfes weitere
   Makroschachtelungen auftreten */

static Boolean MacroStart(void)
{
  return ((Memo("MACRO")) || (Memo("IRP")) || (Memo("IRPC")) || (Memo("REPT")) || (Memo("WHILE")));
}

static Boolean MacroEnd(void)
{
  if (Memo("ENDM"))
  {
    WasMACRO = True;
    return True;
  }
  else
    return False;
}

typedef void (*tMacroArgCallback)(Boolean CtrlArg, const tStrComp *pArg, void *pUser);

static void ProcessMacroArgs(tMacroArgCallback Callback, void *pUser)
{
  tStrComp *pArg;
  int l;

  for (pArg = ArgStr + 1; pArg <= ArgStr + ArgCnt; pArg++)
  {
    l = strlen(pArg->Str);
    if ((l >= 2) && (pArg->Str[0] == '{') && (pArg->Str[l - 1] == '}'))
    {
      tStrComp Arg;

      StrCompRefRight(&Arg, pArg, 1);
      StrCompShorten(&Arg, 1);
      Callback(TRUE, &Arg, pUser);
    }
    else
    {
      Callback(FALSE, pArg, pUser);
    }
  }
}

/*-------------------------------------------------------------------------*/
/* Dieser Einleseprozessor dient nur dazu, eine fehlerhafte Makrodefinition
  bis zum Ende zu ueberlesen */

static void WaitENDM_Processor(void)
{
  POutputTag Tmp;

  if (MacroStart())
    FirstOutputTag->NestLevel++;
  else if (MacroEnd())
    FirstOutputTag->NestLevel--;
  if (FirstOutputTag->NestLevel <= -1)
  {
    Tmp = FirstOutputTag;
    FirstOutputTag = Tmp->Next;
    free(Tmp);
  }
}

static void AddWaitENDM_Processor(void)
{
  POutputTag Neu;

  Neu = GenerateOUTProcessor(WaitENDM_Processor, ErrNum_OpenMacro);
  Neu->Next = FirstOutputTag;
  FirstOutputTag = Neu;
}

/*-------------------------------------------------------------------------*/
/* normale Makros */

static void ComputeMacroStrings(PInputTag Tag)
{
  StringRecPtr Lauf;

  /* recompute # of params */

  if (Tag->UsesNumArgs)
    sprintf(Tag->NumArgs, "%d", Tag->ParCnt);

  /* recompute 'all string' parameter */

  if (Tag->UsesAllArgs)
  {
    Tag->AllArgs[0] = '\0';
    Lauf = Tag->Params;
    while (Lauf)
    {
      if (Tag->AllArgs[0] != '\0')
        strmaxcat(Tag->AllArgs, ",", STRINGSIZE);
      strmaxcat(Tag->AllArgs, Lauf->Content, STRINGSIZE);
      Lauf = Lauf->Next;
    }
  }
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* Diese Routine leitet die Quellcodezeilen bei der Makrodefinition in den
   Makro-Record um */

static void MACRO_OutProcessor(void)
{
  POutputTag Tmp;
  int z;
  StringRecPtr l;
  PMacroRec GMacro;
  String s;

  WasMACRO = True;

  /* write preprocessed output to file ? */

  if ((MacroOutput) && (FirstOutputTag->DoExport))
  {
    errno = 0;
    fprintf(MacroFile, "%s\n", OneLine);
    ChkIO(ErrNum_FileWriteError);
  }

  /* check for additional nested macros resp. end of definition */

  if (MacroStart())
    FirstOutputTag->NestLevel++;
  else if (MacroEnd())
    FirstOutputTag->NestLevel--;

  /* still lines to put into the macro body ? */

  if (FirstOutputTag->NestLevel != -1)
  {
    strmaxcpy(s, OneLine, STRINGSIZE);
    KillCtrl(s);

    /* compress into tokens */

    l = FirstOutputTag->ParamNames;
    for (z = 1; z <= FirstOutputTag->Mac->ParamCount; z++)
      CompressLine(GetStringListNext(&l), z, s, sizeof(s), CaseSensitive);

    /* reserved argument names are never case-sensitive */

    if (HasAttrs)
      CompressLine(AttrName, ArgCntMax + 1, s, sizeof(s), FALSE);
    if (CompressLine(ArgCName, ArgCntMax + 2, s, sizeof(s), FALSE) > 0)
      FirstOutputTag->UsesNumArgs = TRUE;
    if (CompressLine(AllArgName, ArgCntMax + 3, s, sizeof(s), FALSE) > 0)
      FirstOutputTag->UsesAllArgs = TRUE;
    if (FirstOutputTag->Mac->LocIntLabel)
      CompressLine(LabelName, ArgCntMax + 4, s, sizeof(s), FALSE);

    AddStringListLast(&(FirstOutputTag->Mac->FirstLine), s);
  }

  /* otherwise, finish definition */

  if (FirstOutputTag->NestLevel == -1)
  {
    if (IfAsm)
    {
      FirstOutputTag->Mac->UsesNumArgs = FirstOutputTag->UsesNumArgs;
      FirstOutputTag->Mac->UsesAllArgs = FirstOutputTag->UsesAllArgs;
      FirstOutputTag->Mac->ParamNames = FirstOutputTag->ParamNames;
      FirstOutputTag->ParamNames = NULL;
      FirstOutputTag->Mac->ParamDefVals = FirstOutputTag->ParamDefVals;
      FirstOutputTag->ParamDefVals = NULL;
      AddMacro(FirstOutputTag->Mac, FirstOutputTag->PubSect, True);
      if ((FirstOutputTag->DoGlobCopy) && (SectionStack))
      {
        GMacro = (PMacroRec) malloc(sizeof(MacroRec));
        GMacro->Name = as_strdup(FirstOutputTag->GName);
        GMacro->ParamCount = FirstOutputTag->Mac->ParamCount;
        GMacro->FirstLine = DuplicateStringList(FirstOutputTag->Mac->FirstLine);
        GMacro->ParamNames = DuplicateStringList(FirstOutputTag->Mac->ParamNames);
        GMacro->ParamDefVals = DuplicateStringList(FirstOutputTag->Mac->ParamDefVals);
        GMacro->UsesNumArgs = FirstOutputTag->Mac->UsesNumArgs;
        GMacro->UsesAllArgs = FirstOutputTag->Mac->UsesAllArgs;
        AddMacro(GMacro, FirstOutputTag->GlobSect, False);
      }
    }
    else
    {
      ClearMacroRec(&(FirstOutputTag->Mac), TRUE);
    }

    Tmp = FirstOutputTag;
    FirstOutputTag = Tmp->Next;
    ClearStringList(&(Tmp->ParamNames));
    ClearStringList(&(Tmp->ParamDefVals));
    free(Tmp);
  }
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* Hierher kommen bei einem Makroaufruf die expandierten Zeilen */

Boolean MACRO_Processor(PInputTag PInp, char *erg)
{
  StringRecPtr Lauf;
  int z;
  Boolean Result;

  Result = True;

  /* run to current line */

  Lauf = PInp->Lines;
  for (z = 1; z <= PInp->LineZ - 1; z++)
    Lauf = Lauf->Next;
  strcpy(erg, Lauf->Content);

  /* process parameters */

  Lauf = PInp->Params;
  for (z = 1; z <= PInp->ParCnt; z++)
  {
    ExpandLine(Lauf->Content, z, erg, STRINGSIZE);
    Lauf = Lauf->Next;
  }

  /* process special parameters */

  if (HasAttrs)
    ExpandLine(PInp->SaveAttr, ArgCntMax + 1, erg, STRINGSIZE);
  if (PInp->UsesNumArgs)
    ExpandLine(PInp->NumArgs, ArgCntMax + 2, erg, STRINGSIZE);
  if (PInp->UsesAllArgs)
    ExpandLine(PInp->AllArgs, ArgCntMax + 3, erg, STRINGSIZE);
  if (PInp->Macro->LocIntLabel)
    ExpandLine(PInp->SaveLabel, ArgCntMax + 4, erg, STRINGSIZE);

  CurrLine = PInp->StartLine;
  InMacroFlag = True;

  /* before the first line, start a new local symbol space */

  if ((PInp->LineZ == 1) && (!PInp->GlobalSymbols))
    PushLocHandle(GetLocHandle());

  /* signal the end of the macro */

  if (++(PInp->LineZ) > PInp->LineCnt)
    Result = False;

  return Result;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* Initialisierung des Makro-Einleseprozesses */

static Boolean ReadMacro_SearchArg(const char *pTest, const char *pComp, Boolean *pErg)
{
  if (!strcasecmp(pTest, pComp))
  {
    *pErg = True;
    return True;
  }
  else if ((strlen(pTest) > 2) && (!strncasecmp(pTest, "NO", 2)) && (!strcasecmp(pTest + 2, pComp)))
  {
    *pErg = False;
    return True;
  }
  else
    return False;
}

static Boolean ReadMacro_SearchSect(char *Test_O, char *Comp, Boolean *Erg, LongInt *Section)
{
  char *p;
  String Test, Sect;

  strmaxcpy(Test, Test_O, STRINGSIZE); KillBlanks(Test);
  p = strchr(Test, ':');
  if (!p)
    *Sect = '\0';
  else
  {
    strmaxcpy(Sect, p + 1, STRINGSIZE);
    *p = '\0';
  }
  if ((strlen(Test) > 2) && (!strncasecmp(Test, "NO", 2)) && (!strcasecmp(Test + 2, Comp)))
  {
    *Erg = False;
    return True;
  }
  else if (!strcasecmp(Test, Comp))
  {
    tStrComp TmpComp;

    *Erg = True;
    StrCompMkTemp(&TmpComp, Sect);
    return (IdentifySection(&TmpComp, Section));
  }
  else
    return False;
}

typedef struct
{
  String PList;
  POutputTag pOutputTag;
  tLstMacroExpMod LstMacroExpMod;
  Boolean DoPublic, DoIntLabel, GlobalSymbols;
  Boolean ErrFlag;
  int ParamCount;
} tReadMacroContext;

static void ExpandPList(String PList, const char *pArg, Boolean CtrlArg)
{
  if (!*PList)
    strmaxcat(PList, ",", STRINGSIZE);
  if (CtrlArg)
    strmaxcat(PList, "{", STRINGSIZE);
  strmaxcat(PList, pArg, STRINGSIZE);
  if (CtrlArg)
    strmaxcat(PList, "}", STRINGSIZE);
}

static void ProcessMACROArgs(Boolean CtrlArg, const tStrComp *pArg, void *pUser)
{
  tReadMacroContext *pContext = (tReadMacroContext*)pUser;

  if (CtrlArg)
  {
    Boolean DoMacExp;

    if (ReadMacro_SearchArg(pArg->Str, "EXPORT", &(pContext->pOutputTag->DoExport)));
    else if (ReadMacro_SearchArg(pArg->Str, "GLOBALSYMBOLS", &pContext->GlobalSymbols));
    else if (ReadMacro_SearchArg(pArg->Str, "EXPAND", &DoMacExp))
    {
      if (DoMacExp)
        pContext->LstMacroExpMod.SetAll = True;
      else
        pContext->LstMacroExpMod.ClrAll = True;
      ExpandPList(pContext->PList, pArg->Str, CtrlArg);
    }
    else if (ReadMacro_SearchArg(pArg->Str, "EXPIF", &DoMacExp))
    {
      if (DoMacExp)
        pContext->LstMacroExpMod.ORMask |= eLstMacroExpIf;
      else
        pContext->LstMacroExpMod.ANDMask |= eLstMacroExpIf;
      ExpandPList(pContext->PList, pArg->Str, CtrlArg);
    }
    else if (ReadMacro_SearchArg(pArg->Str, "EXPMACRO", &DoMacExp))
    {
      if (DoMacExp)
        pContext->LstMacroExpMod.ORMask |= eLstMacroExpMacro;
      else
        pContext->LstMacroExpMod.ANDMask |= eLstMacroExpMacro;
      ExpandPList(pContext->PList, pArg->Str, CtrlArg);
    }
    else if (ReadMacro_SearchArg(pArg->Str, "INTLABEL", &pContext->DoIntLabel))
    {
      ExpandPList(pContext->PList, pArg->Str, CtrlArg);
    }
    else if (ReadMacro_SearchSect(pArg->Str, "GLOBAL", &(pContext->pOutputTag->DoGlobCopy), &(pContext->pOutputTag->GlobSect)));
    else if (ReadMacro_SearchSect(pArg->Str, "PUBLIC", &pContext->DoPublic, &(pContext->pOutputTag->PubSect)));
    else
    {
      WrStrErrorPos(ErrNum_UnknownMacArg, pArg);
      pContext->ErrFlag = True;
    }
  }
  else
  {
    char *pDefault;
    tStrComp Arg = *pArg;

    ExpandPList(pContext->PList, Arg.Str, CtrlArg);
    pDefault = QuotPos(Arg.Str, '=');
    if (pDefault)
    {
      *pDefault++ = '\0';
      KillPostBlanksStrComp(&Arg);
      KillPrefBlanksStrComp(&Arg);
    }
    if (!ChkMacSymbName(Arg.Str))
    {
      WrStrErrorPos(ErrNum_InvSymName, &Arg);
      pContext->ErrFlag = True;
    }
    if (!CaseSensitive)
      UpString(Arg.Str);
    AddStringListLast(&(pContext->pOutputTag->ParamNames), Arg.Str);
    AddStringListLast(&(pContext->pOutputTag->ParamDefVals), pDefault ? pDefault : "");
    pContext->ParamCount++;
  }
}

static void ReadMacro(void)
{
  PSaveSection RunSection;
  PMacroRec OneMacro;
  tReadMacroContext Context;
  LongInt HSect;
  String MacroName;

  WasMACRO = True;

  CodeLen = 0;
  Context.ErrFlag = False;

  /* Makronamen pruefen */
  /* Definition nur im ersten Pass */

  if (PassNo != 1)
    Context.ErrFlag = True;
  else if (!ExpandStrSymbol(MacroName, sizeof(MacroName), &LabPart))
    Context.ErrFlag = True;
  else if (!ChkSymbName(MacroName))
  {
    WrXError(ErrNum_InvSymName, LabPart.Str);
    Context.ErrFlag = True;
  }

  /* create tag */

  Context.pOutputTag = GenerateOUTProcessor(MACRO_OutProcessor, ErrNum_OpenMacro);
  Context.pOutputTag->Next = FirstOutputTag;

  /* check arguments, sort out control directives */

  InitLstMacroExpMod(&Context.LstMacroExpMod);
  Context.LstMacroExpMod.ORMask = LstMacroExp;
  Context.LstMacroExpMod.ANDMask = eLstMacroExpAll & ~LstMacroExp;
  Context.DoPublic = False;
  Context.DoIntLabel = False;
  Context.GlobalSymbols = False;
  *Context.PList = '\0';
  Context.ParamCount = 0;
  ProcessMacroArgs(ProcessMACROArgs, &Context);

  /* Abbruch bei Fehler */

  if (Context.ErrFlag)
  {
    ClearStringList(&(Context.pOutputTag->ParamNames));
    ClearStringList(&(Context.pOutputTag->ParamDefVals));
    free(Context.pOutputTag);
    AddWaitENDM_Processor();
    return;
  }

  /* Bei Globalisierung Namen des Extramakros ermitteln */

  if (Context.pOutputTag->DoGlobCopy)
  {
    strmaxcpy(Context.pOutputTag->GName, MacroName, STRINGSIZE);
    RunSection = SectionStack;
    HSect = MomSectionHandle;
    while ((HSect != Context.pOutputTag->GlobSect) && (RunSection != NULL))
    {
      strmaxprep(Context.pOutputTag->GName, "_", STRINGSIZE);
      strmaxprep(Context.pOutputTag->GName, GetSectionName(HSect), STRINGSIZE);
      HSect = RunSection->Handle;
      RunSection = RunSection->Next;
    }
  }
  if (!Context.DoPublic)
    Context.pOutputTag->PubSect = MomSectionHandle;

  /* chain in */

  OneMacro = (PMacroRec) calloc(1, sizeof(MacroRec));
  OneMacro->FirstLine =
  OneMacro->ParamNames =
  OneMacro->ParamDefVals = NULL;
  Context.pOutputTag->Mac = OneMacro;

  if ((MacroOutput) && (Context.pOutputTag->DoExport))
  {
    errno = 0;
    fprintf(MacroFile, "%s MACRO %s\n",
            Context.pOutputTag->DoGlobCopy ? Context.pOutputTag->GName : MacroName,
            Context.PList);
    ChkIO(ErrNum_FileWriteError);
  }

  OneMacro->UseCounter = 0;
  OneMacro->Name = as_strdup(MacroName);
  OneMacro->ParamCount = Context.ParamCount;
  OneMacro->FirstLine = NULL;
  OneMacro->LstMacroExpMod = Context.LstMacroExpMod;
  OneMacro->LocIntLabel = Context.DoIntLabel;
  OneMacro->GlobalSymbols = Context.GlobalSymbols;

  FirstOutputTag = Context.pOutputTag;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* Beendigung der Expansion eines Makros */

static void MACRO_Cleanup(PInputTag PInp)
{
  ClearStringList(&(PInp->Params));
}

static Boolean MACRO_GetPos(PInputTag PInp, char *dest)
{
  String Tmp;

  sprintf(Tmp, LongIntFormat, PInp->LineZ - 1);
  sprintf(dest, "%s(%s) ", PInp->SpecName.Str, Tmp);
  return False;
}

static void MACRO_Restorer(PInputTag PInp)
{
  /* discard the local symbol space */

  if (!PInp->GlobalSymbols)
    PopLocHandle();

  /* undo the recursion counter by one */

  if ((PInp->Macro) && (PInp->Macro->UseCounter > 0))
    PInp->Macro->UseCounter--;

  /* restore list flag */

  DoLst = PInp->OrigDoLst;

  /* decrement macro nesting counter only if this actually was a macro */

  if (PInp->Processor == MACRO_Processor)
    MacroNestLevel--;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* Dies initialisiert eine Makroexpansion */

static void ExpandMacro(PMacroRec OneMacro)
{
  int z1, z2;
  StringRecPtr Lauf, pDefault, pParamName, pArg;
  PInputTag Tag = NULL;
  Boolean NamedArgs;
  char *p;

  CodeLen = 0;

  if ((NestMax > 0) && (OneMacro->UseCounter > NestMax)) WrError(ErrNum_RekMacro);
  else
  {
    OneMacro->UseCounter++;

    /* 1. Tag erzeugen */

    Tag = GenerateProcessor();
    Tag->Processor = MACRO_Processor;
    Tag->Restorer  = MACRO_Restorer;
    Tag->Cleanup   = MACRO_Cleanup;
    Tag->GetPos    = MACRO_GetPos;
    Tag->Macro     = OneMacro;
    Tag->GlobalSymbols = OneMacro->GlobalSymbols;
    Tag->UsesNumArgs = OneMacro->UsesNumArgs;
    Tag->UsesAllArgs = OneMacro->UsesAllArgs;
    strmaxcpy(Tag->SpecName.Str, OneMacro->Name, STRINGSIZE);
    strmaxcpy(Tag->SaveAttr, AttrPart.Str, STRINGSIZE);
    if (OneMacro->LocIntLabel)
      strmaxcpy(Tag->SaveLabel, LabPart.Str, STRINGSIZE);
    Tag->IsMacro   = True;

    /* 2. Store special parameters - in the original form.
          Omit this if they aren't used at all in the macro's body. */

    Tag->NumArgs[0] = '\0';
    if (Tag->UsesNumArgs)
      sprintf(Tag->NumArgs, "%d", ArgCnt);
    Tag->AllArgs[0] = '\0';
    if (Tag->UsesAllArgs)
    {
      for (z1 = 1; z1 <= ArgCnt; z1++)
      {
        if (z1 != 1) strmaxcat(Tag->AllArgs, ",", STRINGSIZE);
        strmaxcat(Tag->AllArgs, ArgStr[z1].Str, STRINGSIZE);
      }
    }
    Tag->ParCnt = OneMacro->ParamCount;

    /* 3. generate argument list */

    /* 3a. initialize with empty defaults - order is irrelevant at this point: */

    for (z1 = OneMacro->ParamCount; z1 >= 1; z1--)
      AddStringListFirst(&(Tag->Params), NULL);

    /* 3b. walk over given arguments */

    NamedArgs = False;
    for (z1 = 1; z1 <= ArgCnt; z1++)
    {
      if (!CaseSensitive) UpString(ArgStr[z1].Str);

      /* explicit name given? */

      p = QuotPos(ArgStr[z1].Str, '=');

      /* if parameter name given... */

      if (p)
      {
        /* split it off */

        *p++ = '\0';
        KillPostBlanksStrComp(&ArgStr[z1]);
        KillPrefBlanks(p);

        /* search parameter by name */

        for (pParamName = OneMacro->ParamNames, pArg = Tag->Params;
             pParamName; pParamName = pParamName->Next, pArg = pArg->Next)
          if (!strcmp(ArgStr[z1].Str, pParamName->Content))
          {
            if (pArg->Content)
            {
              WrXError(ErrNum_MacArgRedef, pParamName->Content);
              free(pArg->Content);
            }
            pArg->Content = as_strdup(p);
            break;
          }
        if (!pParamName)
          WrStrErrorPos(ErrNum_UndefKeyArg, &ArgStr[z1]);

        /* set flag that no unnamed args are any longer allowed */

        NamedArgs = True;
      }

      /* do not mix unnamed with named arguments: */

      else if (NamedArgs)
        WrError(ErrNum_NoPosArg);

      /* empty positional parameters mean using defaults - insert non-empty args here: */

      else if ((z1 <= OneMacro->ParamCount) && (strlen(ArgStr[z1].Str) > 0))
      {
        pArg = Tag->Params;
        pParamName = OneMacro->ParamNames;
        for (z2 = 0; z2 < z1 - 1; z2++)
        {
          pParamName = pParamName->Next;
          pArg = pArg->Next;
        }
        if (pArg->Content)
        {
          WrXError(ErrNum_MacArgRedef, pParamName->Content);
          free(pArg->Content);
        }
        pArg->Content = as_strdup(ArgStr[z1].Str);
      }

      /* excess unnamed arguments: append at end of list */

      else if (z1 > OneMacro->ParamCount)
        AddStringListLast(&(Tag->Params), ArgStr[z1].Str);
    }

    /* 3c. fill in defaults */

    for (pParamName = OneMacro->ParamNames, pArg = Tag->Params, pDefault = OneMacro->ParamDefVals;
             pParamName; pParamName = pParamName->Next, pArg = pArg->Next, pDefault = pDefault->Next)
      if (!pArg->Content)
        pArg->Content = as_strdup(pDefault->Content);

    /* 4. Zeilenliste anhaengen */

    Tag->Lines = OneMacro->FirstLine;
    Tag->IsEmpty = !OneMacro->FirstLine;
    Lauf = OneMacro->FirstLine;
    while (Lauf)
    {
      Tag->LineCnt++;
      Lauf = Lauf->Next;
    }
  }

  /* 5. anhaengen */

  if (Tag)
  {
    if (IfAsm)
    {
      /* override has higher prio, so apply as second */

      NextDoLst = ApplyLstMacroExpMod(DoLst, &OneMacro->LstMacroExpMod);
      NextDoLst = ApplyLstMacroExpMod(NextDoLst, &LstMacroExpOverride);
      Tag->Next = FirstInputTag;
      FirstInputTag = Tag;
      MacroNestLevel++;
    }
    else
    {
      ClearStringList(&(Tag->Params)); free(Tag);
    }
  }
}

/*-------------------------------------------------------------------------*/
/* vorzeitiger Abbruch eines Makros */

static void ExpandEXITM(void)
{
  WasMACRO = True;

  if (!ChkArgCnt(0, 0));
  else if (!FirstInputTag) WrError(ErrNum_EXITMOutsideMacro);
  else if (!FirstInputTag->IsMacro) WrError(ErrNum_EXITMOutsideMacro);
  else if (IfAsm)
  {
    FirstInputTag->Cleanup(FirstInputTag);
    RestoreIFs(FirstInputTag->IfLevel);
    FirstInputTag->IsEmpty = True;
  }
}

/*-------------------------------------------------------------------------*/
/* discard first argument */

static void ExpandSHIFT(void)
{
  PInputTag RunTag;

  WasMACRO = True;

  if (!ChkArgCnt(0, 0));
  else if (!FirstInputTag) WrError(ErrNum_EXITMOutsideMacro);
  else if (!FirstInputTag->IsMacro) WrError(ErrNum_EXITMOutsideMacro);
  else if (IfAsm)
  {
    for (RunTag = FirstInputTag; RunTag; RunTag = RunTag->Next)
      if (RunTag->Processor == MACRO_Processor)
        break;

    if ((RunTag) && (RunTag->Params))
    {
      GetAndCutStringList(&(RunTag->Params));
      RunTag->ParCnt--;
      ComputeMacroStrings(RunTag);
    }
  }
}

/*-------------------------------------------------------------------------*/
/*--- IRP (was das bei MASM auch immer heissen mag...)
      Ach ja: Individual Repeat! Danke Bernhard, jetzt hab'
      ich's gerafft! -----------------------*/

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* Diese Routine liefert bei der Expansion eines IRP-Statements die expan-
  dierten Zeilen */

Boolean IRP_Processor(PInputTag PInp, char *erg)
{
  StringRecPtr Lauf;
  int z;
  Boolean Result;

  Result = True;

  /* increment line counter only if contents came from a true file */

  CurrLine = PInp->StartLine;
  if (PInp->FromFile)
    CurrLine += PInp->LineZ;

  /* first line? Then open new symbol space and reset line pointer */

  if (PInp->LineZ == 1)
  {
    if (!PInp->GlobalSymbols)
    {
      if (!PInp->First) PopLocHandle();
      PushLocHandle(GetLocHandle());
    }
    PInp->First = False;
    PInp->LineRun = PInp->Lines;
  }

  /* extract line */

  strcpy(erg, PInp->LineRun->Content);
  PInp->LineRun = PInp->LineRun->Next;

  /* expand iteration parameter */

  Lauf = PInp->Params; for (z = 1; z <= PInp->ParZ - 1; z++)
    Lauf = Lauf->Next;
  ExpandLine(Lauf->Content, 1, erg, STRINGSIZE);

  /* end of body? then reset to line 1 and exit if this was the last iteration */

  if (++(PInp->LineZ) > PInp->LineCnt)
  {
    PInp->LineZ = 1;
    if (++(PInp->ParZ) > PInp->ParCnt)
      Result = False;
  }

  return Result;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* Aufraeumroutine IRP/IRPC */

static void IRP_Cleanup(PInputTag PInp)
{
  StringRecPtr Lauf;

  /* letzten Parameter sichern, wird evtl. noch fuer GetPos gebraucht!
     ... SaveAttr ist aber frei */
  if (PInp->Processor == IRP_Processor)
  {
    for (Lauf = PInp->Params; Lauf->Next; Lauf = Lauf->Next);
    strmaxcpy(PInp->SaveAttr, Lauf->Content, STRINGSIZE);
  }

  ClearStringList(&(PInp->Lines));
  ClearStringList(&(PInp->Params));
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* Posisionsangabe im IRP(C) fuer Fehlermeldungen */

static Boolean IRP_GetPos(PInputTag PInp, char *dest)
{
  int z, ParZ = PInp->ParZ, LineZ = PInp->LineZ;
  char *IRPType, *IRPVal, tmp[10];

  /* LineZ/ParZ already hopped to next line - step one back: */

  if (--LineZ <= 0)
  {
    LineZ = PInp->LineCnt;
    ParZ--;
  }

  if (PInp->Processor == IRP_Processor)
  {
    IRPType = "IRP";
    if (*PInp->SaveAttr != '\0')
      IRPVal = PInp->SaveAttr;
    else
    {
      StringRecPtr Lauf = PInp->Params;

      for (z = 1; z <= ParZ - 1; z++)
        Lauf = Lauf->Next;
      IRPVal = Lauf->Content;
    }
  }
  else
  {
    IRPType = "IRPC";
    sprintf(tmp, "'%c'", PInp->SpecName.Str[ParZ - 1]);
    IRPVal = tmp;
  }

  sprintf(dest, "%s:%s(%ld) ", IRPType, IRPVal, (long)LineZ);

  return False;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* Diese Routine sammelt waehrend der Definition eines IRP(C)-Statements die
  Quellzeilen ein */

static void IRP_OutProcessor(void)
{
  POutputTag Tmp;
  StringRecPtr Dummy;
  String s;

  WasMACRO = True;

  /* Schachtelungen mitzaehlen */

  if (MacroStart())
    FirstOutputTag->NestLevel++;
  else if (MacroEnd())
    FirstOutputTag->NestLevel--;

  /* falls noch nicht zuende, weiterzaehlen */

  if (FirstOutputTag->NestLevel > -1)
  {
    strmaxcpy(s, OneLine, STRINGSIZE); KillCtrl(s);
    CompressLine(GetStringListFirst(FirstOutputTag->ParamNames, &Dummy), 1, s, sizeof(s), CaseSensitive);
    AddStringListLast(&(FirstOutputTag->Tag->Lines), s);
    FirstOutputTag->Tag->LineCnt++;
  }

  /* alles zusammen? Dann umhaengen */

  if (FirstOutputTag->NestLevel == -1)
  {
    Tmp = FirstOutputTag;
    FirstOutputTag = FirstOutputTag->Next;
    Tmp->Tag->IsEmpty = !Tmp->Tag->Lines;
    if (IfAsm)
    {
      NextDoLst = DoLst & LstMacroExp;
      NextDoLst = ApplyLstMacroExpMod(NextDoLst, &LstMacroExpOverride);
      Tmp->Tag->Next = FirstInputTag;
      FirstInputTag = Tmp->Tag;
    }
    else
    {
      ClearStringList(&(Tmp->Tag->Lines));
      ClearStringList(&(Tmp->Tag->Params));
      free(Tmp->Tag);
    }
    ClearStringList(&(Tmp->ParamNames));
    free(Tmp);
  }
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* Initialisierung der IRP-Bearbeitung */

typedef struct
{
  Boolean ErrFlag;
  Boolean GlobalSymbols;
  int ArgCnt;
  POutputTag pOutputTag;
  StringList Params;
} tExpandIRPContext;

static void ProcessIRPArgs(Boolean CtrlArg, const tStrComp *pArg, void *pUser)
{
  tExpandIRPContext *pContext = (tExpandIRPContext*)pUser;

  if (CtrlArg)
  {
    if (ReadMacro_SearchArg(pArg->Str, "GLOBALSYMBOLS", &pContext->GlobalSymbols));
    else
    {
      WrStrErrorPos(ErrNum_UnknownMacArg, pArg);
      pContext->ErrFlag = True;
    }
  }
  else
  {
    /* differentiate placeholder & arguments */

    if (0 == pContext->ArgCnt)
    {
      if (!ChkMacSymbName(pArg->Str))
      {
        WrStrErrorPos(ErrNum_InvSymName, pArg);
        pContext->ErrFlag = True;
      }
      else
        AddStringListFirst(&(pContext->pOutputTag->ParamNames), pArg->Str);
    }
    else
    {
      if (!CaseSensitive)
        UpString(pArg->Str);
      AddStringListLast(&(pContext->Params), pArg->Str);
    }
    pContext->ArgCnt++;
  }
}

static void ExpandIRP(void)
{
  PInputTag Tag;
  tExpandIRPContext Context;

  WasMACRO = True;

  /* 0. terminate if conditional assembly bites */

  if (!IfAsm)
  {
    AddWaitENDM_Processor();
    return;
  }

  /* 1. Parameter pruefen */

  Context.ErrFlag = False;
  Context.GlobalSymbols = False;
  Context.ArgCnt = 0;
  Context.Params = NULL;

  Context.pOutputTag = GenerateOUTProcessor(IRP_OutProcessor, ErrNum_OpenIRP);
  Context.pOutputTag->Next      = FirstOutputTag;
  ProcessMacroArgs(ProcessIRPArgs, &Context);

  /* at least parameter & one arg */

  if (!ChkArgCntExt(Context.ArgCnt, 2, ArgCntMax))
    Context.ErrFlag = True;
  if (Context.ErrFlag)
  {
    ClearStringList(&(Context.pOutputTag->ParamNames));
    ClearStringList(&(Context.pOutputTag->ParamDefVals));
    ClearStringList(&(Context.Params));
    free(Context.pOutputTag);
    AddWaitENDM_Processor();
    return;
  }

  /* 2. Tag erzeugen */

  Tag = GenerateProcessor();
  Tag->ParCnt    = Context.ArgCnt - 1;
  Tag->Params    = Context.Params;
  Tag->Processor = IRP_Processor;
  Tag->Restorer  = MACRO_Restorer;
  Tag->Cleanup   = IRP_Cleanup;
  Tag->GetPos    = IRP_GetPos;
  Tag->GlobalSymbols = Context.GlobalSymbols;
  Tag->ParZ      = 1;
  Tag->IsMacro   = True;
  *Tag->SaveAttr = '\0';
  Context.pOutputTag->Tag = Tag;

  /* 4. einbetten */

  FirstOutputTag = Context.pOutputTag;
}

/*--- IRPC: dito fuer Zeichen eines Strings ---------------------------------*/

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* Diese Routine liefert bei der Expansion eines IRPC-Statements die expan-
  dierten Zeilen */

Boolean IRPC_Processor(PInputTag PInp, char *erg)
{
  Boolean Result;
  char tmp[5];

  Result = True;

  /* increment line counter only if contents came from a true file */

  CurrLine = PInp->StartLine;
  if (PInp->FromFile)
    CurrLine += PInp->LineZ;

  /* first line? Then open new symbol space and reset line pointer */

  if (PInp->LineZ == 1)
  {
    if (!PInp->GlobalSymbols)
    {
      if (!PInp->First) PopLocHandle();
      PushLocHandle(GetLocHandle());
    }
    PInp->First = False;
    PInp->LineRun = PInp->Lines;
  }

  /* extract line */

  strcpy(erg, PInp->LineRun->Content);
  PInp->LineRun = PInp->LineRun->Next;

  /* extract iteration parameter */

  *tmp = PInp->SpecName.Str[PInp->ParZ - 1];
  tmp[1] = '\0';
  ExpandLine(tmp, 1, erg, STRINGSIZE);

  /* end of body? then reset to line 1 and exit if this was the last iteration */

  if (++(PInp->LineZ) > PInp->LineCnt)
  {
    PInp->LineZ = 1;
    if (++(PInp->ParZ) > PInp->ParCnt)
      Result = False;
  }

  return Result;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* Initialisierung der IRPC-Bearbeitung */

typedef struct
{
  Boolean ErrFlag;
  Boolean GlobalSymbols;
  int ArgCnt;
  POutputTag pOutputTag;
  String ParameterStr;
  tStrComp Parameter;
} tExpandIRPCContext;

static void ProcessIRPCArgs(Boolean CtrlArg, const tStrComp *pArg, void *pUser)
{
  tExpandIRPCContext *pContext = (tExpandIRPCContext*)pUser;

  if (CtrlArg)
  {
    if (ReadMacro_SearchArg(pArg->Str, "GLOBALSYMBOLS", &pContext->GlobalSymbols));
    else
    {
      WrStrErrorPos(ErrNum_UnknownMacArg, pArg);
      pContext->ErrFlag = True;
    }
  }
  else
  {
    if (0 == pContext->ArgCnt)
    {
      if (!ChkMacSymbName(pArg->Str))
      {
        WrStrErrorPos(ErrNum_InvSymName, pArg);
        pContext->ErrFlag = True;
      }
      else
        AddStringListFirst(&(pContext->pOutputTag->ParamNames), pArg->Str);
    }
    else
    {
      Boolean OK;

      EvalStrStringExpression(pArg, &OK, pContext->Parameter.Str);
      pContext->Parameter.Pos = pArg->Pos;
      if (!OK)
        pContext->ErrFlag = True;
    }
    pContext->ArgCnt++;
  }
}

static void ExpandIRPC(void)
{
  PInputTag Tag;
  tExpandIRPCContext Context;

  WasMACRO = True;

  /* 0. terminate if conditinal assembly bites */

  if (!IfAsm)
  {
    AddWaitENDM_Processor();
    return;
  }

  /* 1.Parameter pruefen */

  Context.ErrFlag = False;
  Context.GlobalSymbols = False;
  Context.ArgCnt = 0;
  StrCompMkTemp(&Context.Parameter, Context.ParameterStr);
  StrCompReset(&Context.Parameter);

  Context.pOutputTag = GenerateOUTProcessor(IRP_OutProcessor, ErrNum_OpenIRPC);
  Context.pOutputTag->Next = FirstOutputTag;
  ProcessMacroArgs(ProcessIRPCArgs, &Context);

  /* parameter & string */

  if (!ChkArgCntExt(Context.ArgCnt, 2, ArgCntMax))
    Context.ErrFlag = True;
  if (Context.ErrFlag)
  {
    ClearStringList(&(Context.pOutputTag->ParamNames));
    AddWaitENDM_Processor();
    return;
  }

  /* 2. Tag erzeugen */

  Tag = GenerateProcessor();
  Tag->ParCnt    = strlen(Context.Parameter.Str);
  Tag->Processor = IRPC_Processor;
  Tag->Restorer  = MACRO_Restorer;
  Tag->Cleanup   = IRP_Cleanup;
  Tag->GetPos    = IRP_GetPos;
  Tag->GlobalSymbols = Context.GlobalSymbols;
  Tag->ParZ      = 1;
  Tag->IsMacro   = True;
  *Tag->SaveAttr = '\0';
  StrCompCopy(&Tag->SpecName, &Context.Parameter);

  /* 4. einbetten */

  Context.pOutputTag->Tag = Tag;
  FirstOutputTag = Context.pOutputTag;
}

/*--- Repetition -----------------------------------------------------------*/

static void REPT_Cleanup(PInputTag PInp)
{
  ClearStringList(&(PInp->Lines));
}

static Boolean REPT_GetPos(PInputTag PInp, char *dest)
{
  int z1 = PInp->ParZ, z2 = PInp->LineZ;

  if (--z2 <= 0)
  {
    z2 = PInp->LineCnt;
    z1--;
  }
  sprintf(dest, "REPT %ld(%ld)", (long)z1, (long)z2);
  return False;
}

Boolean REPT_Processor(PInputTag PInp, char *erg)
{
  Boolean Result;

  Result = True;

  /* increment line counter only if contents came from a true file */

  CurrLine = PInp->StartLine;
  if (PInp->FromFile)
    CurrLine += PInp->LineZ;

  /* first line? Then open new symbol space and reset line pointer */

  if (PInp->LineZ == 1)
  {
    if (!PInp->GlobalSymbols)
    {
      if (!PInp->First) PopLocHandle();
      PushLocHandle(GetLocHandle());
    }
    PInp->First = False;
    PInp->LineRun = PInp->Lines;
  }

  /* extract line */

  strcpy(erg, PInp->LineRun->Content);
  PInp->LineRun = PInp->LineRun->Next;

  /* last line of body? Then increment count and stop if last iteration */

  if ((++PInp->LineZ) > PInp->LineCnt)
  {
    PInp->LineZ = 1;
    if ((++PInp->ParZ) > PInp->ParCnt)
      Result = False;
  }

  return Result;
}

static void REPT_OutProcessor(void)
{
  POutputTag Tmp;

  WasMACRO = True;

  /* Schachtelungen mitzaehlen */

  if (MacroStart())
    FirstOutputTag->NestLevel++;
  else if (MacroEnd())
    FirstOutputTag->NestLevel--;

  /* falls noch nicht zuende, weiterzaehlen */

  if (FirstOutputTag->NestLevel > -1)
  {
    AddStringListLast(&(FirstOutputTag->Tag->Lines), OneLine);
    FirstOutputTag->Tag->LineCnt++;
  }

  /* alles zusammen? Dann umhaengen */

  if (FirstOutputTag->NestLevel == -1)
  {
    Tmp = FirstOutputTag;
    FirstOutputTag = FirstOutputTag->Next;
    Tmp->Tag->IsEmpty = !Tmp->Tag->Lines;
    if ((IfAsm) && (Tmp->Tag->ParCnt > 0))
    {
      NextDoLst = DoLst & LstMacroExp;
      NextDoLst = ApplyLstMacroExpMod(NextDoLst, &LstMacroExpOverride);
      Tmp->Tag->Next = FirstInputTag;
      FirstInputTag = Tmp->Tag;
    }
    else
    {
      ClearStringList(&(Tmp->Tag->Lines));
      free(Tmp->Tag);
    }
    free(Tmp);
  }
}

typedef struct
{
  Boolean ErrFlag;
  Boolean GlobalSymbols;
  int ArgCnt;
  LongInt ReptCount;
} tExpandREPTContext;

static void ProcessREPTArgs(Boolean CtrlArg, const tStrComp *pArg, void *pUser)
{
  tExpandREPTContext *pContext = (tExpandREPTContext*)pUser;

  if (CtrlArg)
  {
    if (ReadMacro_SearchArg(pArg->Str, "GLOBALSYMBOLS", &pContext->GlobalSymbols));
    else
    {
      WrStrErrorPos(ErrNum_UnknownMacArg, pArg);
      pContext->ErrFlag = True;
    }
  }
  else
  {
    Boolean ValOK;

    FirstPassUnknown = False;
    pContext->ReptCount = EvalStrIntExpression(pArg, Int32, &ValOK);
    if (FirstPassUnknown)
      WrStrErrorPos(ErrNum_FirstPassCalc, pArg);
    if ((!ValOK) || (FirstPassUnknown))
      pContext->ErrFlag = True;
    pContext->ArgCnt++;
  }
}

static void ExpandREPT(void)
{
  PInputTag Tag;
  POutputTag Neu;
  tExpandREPTContext Context;

  WasMACRO = True;

  /* 0. skip everything when conditional assembly is off */

  if (!IfAsm)
  {
    AddWaitENDM_Processor();
    return;
  }

  /* 1. Repetitionszahl ermitteln */

  Context.GlobalSymbols = False;
  Context.ReptCount = 0;
  Context.ErrFlag = False;
  Context.ArgCnt = 0;
  ProcessMacroArgs(ProcessREPTArgs, &Context);

  /* rept count must be present only once */

  if (!ChkArgCntExt(Context.ArgCnt, 1, 1))
    Context.ErrFlag = True;
  if (Context.ErrFlag)
  {
    AddWaitENDM_Processor();
    return;
  }

  /* 2. Tag erzeugen */

  Tag = GenerateProcessor();
  Tag->ParCnt    = Context.ReptCount;
  Tag->Processor = REPT_Processor;
  Tag->Restorer  = MACRO_Restorer;
  Tag->Cleanup   = REPT_Cleanup;
  Tag->GetPos    = REPT_GetPos;
  Tag->GlobalSymbols = Context.GlobalSymbols;
  Tag->IsMacro   = True;
  Tag->ParZ      = 1;

  /* 3. einbetten */

  Neu = GenerateOUTProcessor(REPT_OutProcessor, ErrNum_OpenREPT);
  Neu->Next      = FirstOutputTag;
  Neu->Tag       = Tag;
  FirstOutputTag = Neu;
}

/*- bedingte Wiederholung -------------------------------------------------------*/

static void WHILE_Cleanup(PInputTag PInp)
{
  ClearStringList(&(PInp->Lines));
}

static Boolean WHILE_GetPos(PInputTag PInp, char *dest)
{
  int z1 = PInp->ParZ, z2 = PInp->LineZ;

  if (--z2 <= 0)
  {
    z2 = PInp->LineCnt;
    z1--;
  }
  sprintf(dest, "WHILE %ld/%ld", (long)z1, (long)z2);
  return False;
}

Boolean WHILE_Processor(PInputTag PInp, char *erg)
{
  int z;
  Boolean OK, Result;

  /* increment line counter only if this came from a true file */

  CurrLine = PInp->StartLine;
  if (PInp->FromFile)
    CurrLine += PInp->LineZ;

  /* if this is the first line of the loop body, open a new handle
     for macro-local symbols and drop the old one if this was not the
     first pass through the body. */

  if (PInp->LineZ == 1)
  {
    if (!PInp->GlobalSymbols)
    {
      if (!PInp->First)
        PopLocHandle();
      PushLocHandle(GetLocHandle());
    }
    PInp->First = False;
    PInp->LineRun = PInp->Lines;
  }

  /* evaluate condition before first line */

  if (PInp->LineZ == 1)
  {
    z = EvalStrIntExpression(&PInp->SpecName, Int32, &OK);
    Result = (OK && (z != 0));
  }
  else
    Result = True;

  if (Result)
  {
    /* get line of body */

    strcpy(erg, PInp->LineRun->Content);
    PInp->LineRun = PInp->LineRun->Next;

    /* in case this is the last line of the body, reset counters */

    if ((++PInp->LineZ) > PInp->LineCnt)
    {
      PInp->LineZ = 1;
      PInp->ParZ++;
    }
  }

  /* nasty last line... */

  else
    *erg = '\0';

  return Result;
}

static void WHILE_OutProcessor(void)
{
  POutputTag Tmp;
  Boolean OK;
  LongInt Erg;

  WasMACRO = True;

  /* Schachtelungen mitzaehlen */

  if (MacroStart())
    FirstOutputTag->NestLevel++;
  else if (MacroEnd())
    FirstOutputTag->NestLevel--;

  /* falls noch nicht zuende, weiterzaehlen */

  if (FirstOutputTag->NestLevel > -1)
  {
    AddStringListLast(&(FirstOutputTag->Tag->Lines), OneLine);
    FirstOutputTag->Tag->LineCnt++;
  }

  /* alles zusammen? Dann umhaengen */

  if (FirstOutputTag->NestLevel == -1)
  {
    Tmp = FirstOutputTag;
    FirstOutputTag = FirstOutputTag->Next;
    Tmp->Tag->IsEmpty = !Tmp->Tag->Lines;
    FirstPassUnknown = False;
    Erg = EvalStrIntExpression(&Tmp->Tag->SpecName, Int32, &OK);
    if (FirstPassUnknown)
      WrError(ErrNum_FirstPassCalc);
    OK = (OK && (!FirstPassUnknown) && (Erg != 0));
    if ((IfAsm) && (OK))
    {
      NextDoLst = DoLst & LstMacroExp;
      NextDoLst = ApplyLstMacroExpMod(NextDoLst, &LstMacroExpOverride);
      Tmp->Tag->Next = FirstInputTag;
      FirstInputTag = Tmp->Tag;
    }
    else
    {
      ClearStringList(&(Tmp->Tag->Lines));
      free(Tmp->Tag);
    }
    free(Tmp);
  }
}

typedef struct
{
  Boolean ErrFlag;
  Boolean GlobalSymbols;
  int ArgCnt;
  String SpecNameStr;
  tStrComp SpecName;
} tExpandWHILEContext;

static void ProcessWHILEArgs(Boolean CtrlArg, const tStrComp *pArg, void *pUser)
{
  tExpandWHILEContext *pContext = (tExpandWHILEContext*)pUser;

  if (CtrlArg)
  {
    if (ReadMacro_SearchArg(pArg->Str, "GLOBALSYMBOLS", &pContext->GlobalSymbols));
    else
    {
      WrStrErrorPos(ErrNum_UnknownMacArg, pArg);
      pContext->ErrFlag = True;
    }
  }
  else
  {
    StrCompCopy(&pContext->SpecName, pArg);
    pContext->ArgCnt++;
  }
}

static void ExpandWHILE(void)
{
  PInputTag Tag;
  POutputTag Neu;
  tExpandWHILEContext Context;

  WasMACRO = True;

  /* 0. turned off ? */

  if (!IfAsm)
  {
    AddWaitENDM_Processor();
    return;
  }

  /* 1. Bedingung ermitteln */

  Context.GlobalSymbols = False;
  Context.ErrFlag = False;
  Context.ArgCnt = 0;
  StrCompMkTemp(&Context.SpecName, Context.SpecNameStr);
  StrCompReset(&Context.SpecName);
  ProcessMacroArgs(ProcessWHILEArgs, &Context);

  /* condition must be present only once */

  if (!ChkArgCntExt(Context.ArgCnt, 1, 1))
    Context.ErrFlag = True;
  if (Context.ErrFlag)
  {
    AddWaitENDM_Processor();
    return;
  }

  /* 2. Tag erzeugen */

  Tag = GenerateProcessor();
  Tag->Processor = WHILE_Processor;
  Tag->Restorer  = MACRO_Restorer;
  Tag->Cleanup   = WHILE_Cleanup;
  Tag->GetPos    = WHILE_GetPos;
  Tag->GlobalSymbols = Context.GlobalSymbols;
  Tag->IsMacro   = True;
  Tag->ParZ      = 1;
  StrCompCopy(&Tag->SpecName, &Context.SpecName);

  /* 3. einbetten */

  Neu = GenerateOUTProcessor(WHILE_OutProcessor, ErrNum_OpenWHILE);
  Neu->Next      = FirstOutputTag;
  Neu->Tag       = Tag;
  FirstOutputTag = Neu;
}

/*--------------------------------------------------------------------------*/
/* Einziehen von Include-Files */

static void INCLUDE_Cleanup(PInputTag PInp)
{
  String Tmp;

  fclose(PInp->Datei);
  free(PInp->Buffer);
  LineSum += MomLineCounter;
  if ((*LstName != '\0') && (!QuietMode))
  {
    sprintf(Tmp, LongIntFormat, CurrLine);
    printf("%s(%s)", NamePart(CurrFileName), Tmp);
    printf("%s\n", ClrEol); fflush(stdout);
  }
  if (MakeIncludeList)
    PopInclude();
}

static Boolean INCLUDE_GetPos(PInputTag PInp, char *dest)
{
  String Tmp;
  UNUSED(PInp);

  sprintf(Tmp, LongIntFormat, PInp->LineZ);
  sprintf(dest, GNUErrors ? "%s:%s" : "%s(%s) ", NamePart(PInp->SpecName.Str), Tmp);
  return !GNUErrors;
}

Boolean INCLUDE_Processor(PInputTag PInp, char *Erg)
{
  Boolean Result;
  int Count = 1;

  Result = True;

  if (feof(PInp->Datei))
    *Erg = '\0';
  else
  {
    Count = ReadLnCont(PInp->Datei, Erg, STRINGSIZE);
    /**ChkIO(ErrNum_FileReadError);**/
  }
  PInp->LineZ = CurrLine = (MomLineCounter += Count);
  if (feof(PInp->Datei))
    Result = False;

  return Result;
}

static void INCLUDE_Restorer(PInputTag PInp)
{
  MomLineCounter = PInp->StartLine;
  strmaxcpy(CurrFileName, PInp->SaveAttr, STRINGSIZE);
  IncDepth--;
}

static void ExpandINCLUDE(Boolean SearchPath)
{
  tStrComp FNameArg;
  String FNameArgStr;
  PInputTag Tag;

  if (!IfAsm)
    return;

  if (!ChkArgCnt(1, 1))
    return;

  StrCompMkTemp(&FNameArg, FNameArgStr);
  INCLUDE_SearchCore(&FNameArg, &ArgStr[1], SearchPath);
  
  /* Tag erzeugen */

  Tag = GenerateProcessor();
  Tag->Processor = INCLUDE_Processor;
  Tag->Restorer  = INCLUDE_Restorer;
  Tag->Cleanup   = INCLUDE_Cleanup;
  Tag->GetPos    = INCLUDE_GetPos;
  Tag->Buffer    = (void *) malloc(BufferArraySize);

  /* Sicherung alter Daten */

  Tag->StartLine = MomLineCounter;
  strmaxcpy(Tag->SpecName.Str, FNameArg.Str, STRINGSIZE);
  LineCompReset(&Tag->SpecName.Pos);
  strmaxcpy(Tag->SaveAttr, CurrFileName, STRINGSIZE);

  /* Datei oeffnen */

#ifdef __CYGWIN32__
  DeCygwinPath(FNameArg.Str);
#endif
  Tag->Datei = fopen(FNameArg.Str, "r");
  if (!Tag->Datei) ChkStrIO(ErrNum_OpeningFile, &ArgStr[1]);
  setvbuf(Tag->Datei, Tag->Buffer, _IOFBF, BufferArraySize);

  /* neu besetzen */

  strmaxcpy(CurrFileName, FNameArg.Str, STRINGSIZE); Tag->LineZ = MomLineCounter = 0;
  NextIncDepth++; AddFile(FNameArg.Str);
  PushInclude(FNameArg.Str);

  /* einhaengen */

  Tag->Next = FirstInputTag; FirstInputTag = Tag;
}

/*=========================================================================*/
/* Einlieferung von Zeilen */

static void GetNextLine(char *Line)
{
  PInputTag HTag;

  InMacroFlag = False;

  while ((FirstInputTag) && (FirstInputTag->IsEmpty))
  {
    FirstInputTag->Cleanup(FirstInputTag);
    FirstInputTag->Restorer(FirstInputTag);
    HTag = FirstInputTag;
    FirstInputTag = HTag->Next;
    free(HTag);
  }

  if (!FirstInputTag)
  {
    *Line = '\0';
    return;
  }

  if (!FirstInputTag->Processor(FirstInputTag, Line))
  {
    FirstInputTag->IsEmpty = True;
  }

  MacLineSum++;
}

char *GetErrorPos(void)
{
  String ActPos;
  PInputTag RunTag;
  char *ErgPos = as_strdup(""), *tmppos;
  Boolean Last;

  /* for GNU error message style: */

  if (GNUErrors)
  {
    PInputTag InnerTag = NULL;
    Boolean First = TRUE;
    char *Msg;

    /* we only honor the include positions.  First, print the upper include layers... */

    for (RunTag = FirstInputTag; RunTag; RunTag = RunTag->Next)
      if (RunTag->GetPos == INCLUDE_GetPos)
      {
        if (!InnerTag)
          InnerTag = RunTag;
        else
        {
          Last = RunTag->GetPos(RunTag, ActPos);
          if (First)
          {
            Msg = getmessage(Num_GNUErrorMsg1);
            tmppos = (char *) malloc(strlen(Msg) + 1 + strlen(ActPos) + 1);
            sprintf(tmppos, "%s %s", Msg, ActPos);
          }
          else
          {
            Msg = getmessage(Num_GNUErrorMsgN);
            tmppos = (char *) malloc(strlen(ErgPos) + 2 + strlen(Msg) + 1 + strlen(ActPos) + 1);
            sprintf(tmppos, "%s,\n%s %s", ErgPos, Msg, ActPos);
          }
          First = False;
          free(ErgPos);
          ErgPos = tmppos;
        }
      }

    /* ...append something... */

    if (*ErgPos)
    {
      tmppos = (char *) malloc(strlen(ErgPos) + 3);
      sprintf(tmppos, "%s:\n", ErgPos);
      free(ErgPos);
      ErgPos = tmppos;
    }

    /* ...then the innermost one */

    if (InnerTag)
    {
      InnerTag->GetPos(InnerTag, ActPos);
      tmppos = (char *) malloc(strlen(ErgPos) + strlen(ActPos) + 1);
      sprintf(tmppos, "%s%s", ErgPos, ActPos);
      free(ErgPos);
      ErgPos = tmppos;
    }
  }

  /* otherwise the standard AS position generator: */

  else
  {
    int TotLen = 0, ThisLen;

    for (RunTag = FirstInputTag; RunTag; RunTag = RunTag->Next)
    {
      Last = RunTag->GetPos(RunTag, ActPos);
      ThisLen = strlen(ActPos);
      tmppos = (char *) malloc(TotLen + ThisLen + 1);
      strcpy(tmppos, ActPos);
      strcat(tmppos, ErgPos);
      free(ErgPos);
      ErgPos = tmppos;
      TotLen += ThisLen;
      if (Last)
        break;
    }
  }

  return ErgPos;
}

static Boolean InputEnd(void)
{
  PInputTag Lauf;

  Lauf = FirstInputTag;
  while (Lauf)
  {
    if (!Lauf->IsEmpty)
      return False;
    Lauf = Lauf->Next;
  }

  return True;
}

/*=== Eine Quelldatei ( Haupt-oder Includedatei ) bearbeiten ===============*/

/*--- aus der zerlegten Zeile Code erzeugen --------------------------------*/

Boolean HasLabel(void)
{
  if (!*LabPart.Str)
    return False;
  if (IsDef())
    return False;

  switch (*OpPart.Str)
  {
    case '=':
      return (!Memo("="));
    case ':':
      return (!Memo(":="));
    case 'M':
      return (!Memo("MACRO"));
    case 'F':
      return (!Memo("FUNCTION"));
    case 'L':
      return (!Memo("LABEL"));
    case 'S':
      return (!Memo("SET") || SetIsOccupied()) && (!(Memo("STRUCT") || Memo("STRUC")));
    case 'E':
      if (Memo("EQU") || Memo("ENDSTRUCT") || Memo("ENDS") || Memo("ENDSTRUC") || Memo("ENDUNION"))
        return False;
      return !Memo("EVAL");
    case 'U':
      return (!Memo("UNION"));
    default:
      return True;
  }
}

void HandleLabel(const tStrComp *pName, LargeWord Value)
{
  /* structure element ? */

  if (pInnermostNamedStruct)
  {
    PStructElem pElement = CreateStructElem(pName->Str);

    pElement->Offset = Value;
    AddStructElem(pInnermostNamedStruct->StructRec, pElement);
    AddStructSymbol(pName->Str, Value);
  }

  /* normal label */

  else if (RelSegs)
    EnterRelSymbol(pName, Value, ActPC, False);
  else
    EnterIntSymbolWithFlags(pName, Value, ActPC, False,
                            Value == AfterBSRAddr ? NextLabelFlag_AfterBSR : 0);
}

static void Produce_Code(void)
{
  Byte z;
  PMacroRec OneMacro;
  PStructRec OneStruct;
  Boolean SearchMacros, Found, IsMacro = False, IsStruct = False;

  ActListGran = ListGran();
  WasIF = WasMACRO = False;

  /* Makrosuche unterdruecken ? */

  if (*OpPart.Str == '!')
  {
    SearchMacros = False;
    StrCompCutLeft(&OpPart, 1);
    strcpy(pLOpPart, OpPart.Str);
  }
  else
  {
    SearchMacros = True;
    ExpandStrSymbol(pLOpPart, STRINGSIZE, &OpPart);
    strcpy(OpPart.Str, pLOpPart);
  }
  NLS_UpString(OpPart.Str);

  /* Prozessor eingehaengt ? */

  if (FirstOutputTag)
  {
    FirstOutputTag->Processor();
    return;
  }

  /* otherwise generate code: check for macro/structs here */

  IsMacro = (SearchMacros) && (FoundMacro(&OneMacro));
  if (IsMacro)
    WasMACRO = True;
  if (!IsMacro)
    IsStruct = FoundStruct(&OneStruct, pLOpPart);

  /* no longer at an address right after a BSR? */

  if (EProgCounter() != AfterBSRAddr)
    AfterBSRAddr = 0;

  /* evtl. voranstehendes Label ablegen */

  if ((IfAsm) && ((!IsMacro) || (!OneMacro->LocIntLabel)))
  {
    if (HasLabel())
      HandleLabel(&LabPart, EProgCounter());
  }

  Found = False;
  switch (*OpPart.Str)
  {
    case 'I':
      /* Makroliste ? */
      Found = True;
      if (Memo("IRP")) ExpandIRP();
      else if (Memo("IRPC")) ExpandIRPC();
      else Found = False;
      break;
    case 'R':
      /* Repetition ? */
      Found = True;
      if (Memo("REPT")) ExpandREPT();
      else Found = False;
      break;
    case 'W':
      /* bedingte Repetition ? */
      Found = True;
      if (Memo("WHILE")) ExpandWHILE();
      else Found = False;
      break;
  }

  /* bedingte Assemblierung ? */

  if (!Found)
    WasIF = Found = CodeIFs();

  if (!Found)
    switch (*OpPart.Str)
    {
      case 'M':
        /* Makrodefinition ? */
        Found = True;
        if (Memo("MACRO")) ReadMacro();
        else Found = False;
        break;
      case 'E':
        /* Abbruch Makroexpansion ? */
        Found = True;
        if (Memo("EXITM")) ExpandEXITM();
        else Found = False;
        break;
      case 'S':
        /* shift macro arguments ? */
        Found = True;
        if (Memo("SHIFT")) ExpandSHIFT();
        else Found = False;
        break;
      case 'I':
        /* Includefile? */
        Found = True;
        if (Memo("INCLUDE"))
        {
          ExpandINCLUDE(True);
          MasterFile = False;
        }
        else Found = False;
        break;
    }

  if (Found);

  /* Makroaufruf ? */

  else if (IsMacro)
  {
    if (IfAsm)
    {
      ExpandMacro(OneMacro);
      if ((MacroNestLevel > 1) && (MacroNestLevel < 100))
        sprintf(ListLine, "%*s(MACRO-%u)", MacroNestLevel - 1, "", MacroNestLevel);
      else
        strmaxcpy(ListLine, "(MACRO)", STRINGSIZE);

      /* Macro call itself must not appear in expanded output.  However, a label
         in the same line that is not consumed by the macro must.  In this case,
         dump the source line with the OpPart (macro's name) muted out. */

      if (MacProOutput && (LabPart.Pos.StartCol >= 0) && !OneMacro->LocIntLabel)
        PrintOneLineMuted(MacProFile, OneLine, &OpPart.Pos, &ArgPart.Pos);
    }
  }

  else
  {
    StopfZahl = 0;
    CodeLen = 0;
    DontPrint = False;

#ifdef PROFILE_MEMO
    NumMemo = 0;
#endif

    if (IfAsm)
    {
      /* structure declaration ? */

      if (IsStruct)
      {
        ExpandStruct(OneStruct);
        strmaxcpy(ListLine, OneStruct->IsUnion ? "(UNION)" : "(STRUCT)", STRINGSIZE);
      }
      else if (!CodeGlobalPseudo())
        MakeCode();
      if (MacProOutput && ((*OpPart.Str != '\0') || (*LabPart.Str != '\0') || (*CommPart.Str != '\0')))
      {
        errno = 0;
        fprintf(MacProFile, "%s\n", OneLine);
        ChkIO(ErrNum_ListWrError);
      }
    }

    for (z = 0; z < StopfZahl; z++)
    {
      switch (ActListGran)
      {
        case 4:
          DAsmCode[CodeLen >> 2] = NOPCode;
          break;
        case 2:
          WAsmCode[CodeLen >> 1] = NOPCode;
          break;
        case 1:
          BAsmCode[CodeLen] = NOPCode;
          break;
      }
      CodeLen += ActListGran/Granularity();
    }

#ifdef PROFILE_MEMO
    NumMemoSum += NumMemo;
    NumMemoCnt++;
#endif

    if ((ActPC != StructSeg) && (!ChkPC(PCs[ActPC] + CodeLen - 1)) && (CodeLen != 0))
      WrError(ErrNum_AdrOverflow);
    else
    {
      LargeWord NewPC = PCs[ActPC] + CodeLen;

      if ((!DontPrint) && (ActPC != StructSeg) && (CodeLen > 0))
        BookKeeping();
      if (ActPC == StructSeg)
      {
        if ((CodeLen != 0) && (!DontPrint)) WrError(ErrNum_NotInStruct);
        if (StructStack->StructRec->IsUnion)
        {
          BumpStructLength(StructStack->StructRec, CodeLen);
          CodeLen = 0;
          NewPC = 0;
        }
      }
      else if (CodeOutput)
      {
        PCsUsed[ActPC] = True;
        if (DontPrint)
          NewRecord(PCs[ActPC] + CodeLen);
        else
          WriteBytes();
      }
      PCs[ActPC] = NewPC;
    }
  }

  /* dies ueberprueft implizit, ob von der letzten Eval...-Operation noch
     externe Referenzen liegengeblieben sind. */

  SetRelocs(NULL);
}

/*--- Zeile in Listing zerteilen -------------------------------------------*/

static void SplitLine(void)
{
  const char *pRun, *pEnd, *pPos;

  Retracted = False;

  /* run preprocessor */

  ExpandDefines(OneLine);
  pRun = OneLine;
  pEnd = pRun + strlen(pRun);

  /* If comment is present, ignore everything after it: */

  pPos = QuotPos(pRun, ';');
  if (pPos)
  {
    CommPart.Pos.StartCol = pPos - OneLine;
    CommPart.Pos.Len = strmemcpy(CommPart.Str, STRINGSIZE, pPos, pEnd - pPos);
    pEnd = pPos;
  }
  else
    StrCompReset(&CommPart);

  /* Non-blank character in first column is always label: */

  if ((pRun < pEnd) && (*pRun) && (!myisspace(*pRun)))
  {
    for (pPos = pRun; pPos < pEnd; pPos++)
      if ((myisspace(*pPos)) || (*pPos == ':'))
        break;
    LabPart.Pos.StartCol = pRun - OneLine;
    if (pPos >= pEnd)
    {
      LabPart.Pos.Len = strmemcpy(LabPart.Str, STRINGSIZE, pRun, pEnd - pRun);
      pRun = pEnd;
    }
    else
    {
      LabPart.Pos.Len = strmemcpy(LabPart.Str, STRINGSIZE, pRun, pPos - pRun);
      pRun = pPos + 1;
    }
    if (LabPart.Str[LabPart.Pos.Len - 1] == ':') /* needed? */
      LabPart.Str[--LabPart.Pos.Len] = '\0';
  }
  else
    StrCompReset(&LabPart);

  /* Opcode & Argument trennen */

  while (True)
  {
    for (; (pRun < pEnd) && myisspace(*pRun); pRun++);
    for (pPos = pRun; (pPos < pEnd) && !myisspace(*pPos); pPos++);

    /* If potential OpPart starts with argument divider,
       OpPart is empty and rest of line is all-arguments: */

    if (strchr(DivideChars, *pRun))
    {
      StrCompReset(&OpPart);
      ArgPart.Pos.StartCol = pRun - OneLine;
      ArgPart.Pos.Len = strmemcpy(ArgPart.Str, STRINGSIZE, pRun, pEnd - pRun);
    }
    else
    {
      /* copy out OpPart */

      OpPart.Pos.StartCol = pRun - OneLine;
      OpPart.Pos.Len = strmemcpy(OpPart.Str, STRINGSIZE, pRun, pPos - pRun);

      /* continue after OpPart separator */

      pRun = (pPos < pEnd) ? pPos + 1 : pEnd;

      /* Falls noch kein Label da war, kann es auch ein Label sein */

      if ((*LabPart.Str == '\0') && OpPart.Pos.Len && (OpPart.Str[OpPart.Pos.Len - 1] == ':'))
      {
        OpPart.Str[--OpPart.Pos.Len] = '\0';
        StrCompCopy(&LabPart, &OpPart);
        continue; /* -> retry finding opcode */
      }

      /* save remainder to ArgPart */

      ArgPart.Pos.StartCol = pRun - OneLine;
      ArgPart.Pos.Len = strmemcpy(ArgPart.Str, STRINGSIZE, pRun, pEnd - pRun);
    }
    break;
  }

  ArgCnt = 0;

  /* trailing separator on OpPart means we have to push in another empty argument */

  if (OpPart.Pos.Len && strchr(DivideChars, OpPart.Str[OpPart.Pos.Len - 1]))
  {
    OpPart.Str[--OpPart.Pos.Len] = '\0';
    IncArgCnt();
    strcpy(ArgStr[ArgCnt].Str, "");
    ArgStr[ArgCnt].Pos = ArgPart.Pos;
  }

  /* Attribut abspalten */

  if (HasAttrs)
  {
    const char *pActAttrChar;
    char *pAttrPos, *pActAttrPos;

    pAttrPos = NULL; AttrSplit = ' ';
    for (pActAttrChar = AttrChars; *pActAttrChar; pActAttrChar++)
    {
      pActAttrPos = strchr(OpPart.Str, *pActAttrChar);
      if (pActAttrPos && ((!pAttrPos) || (pActAttrPos < pAttrPos)))
        pAttrPos = pActAttrPos;
    }
    if (pAttrPos)
    {
      AttrSplit = (*pAttrPos);
      AttrPart.Pos.StartCol = OpPart.Pos.StartCol + (pAttrPos + 1 - OpPart.Str);
      AttrPart.Pos.Len = strmemcpy(AttrPart.Str, STRINGSIZE, pAttrPos + 1, strlen(pAttrPos + 1));
      
      *pAttrPos = '\0';
      if ((*OpPart.Str == '\0') && (*AttrPart.Str != '\0'))
      {
        StrCompCopy(&OpPart, &AttrPart);
        StrCompReset(&AttrPart);
      }
    }
    else
      StrCompReset(&AttrPart);
  }
  else
    StrCompReset(&AttrPart);

  KillPostBlanksStrComp(&ArgPart);

  /* Argumente zerteilen: Da alles aus einem String kommt und die Teile alle auch
     so lang sind, koennen wir uns Laengenabfragen sparen */

  if (*ArgPart.Str)
  {
    const char *pDivPos, *pActDiv, *pActDivPos;

    pRun = ArgPart.Str;
    pEnd = pRun + strlen(pRun);
    pActDivPos = NULL;

    /* A separator found in the previous iteration forces another argument,
       even if it will be empty because the separator is right at the end: */

    while ((pRun < pEnd) || pActDivPos)
    {
      while (*pRun && myisspace(*pRun))
        pRun++;
      pDivPos = pEnd;
      for (pActDiv = DivideChars; *pActDiv; pActDiv++)
      {
        pActDivPos = QuotPos(pRun, *pActDiv);
        if (pActDivPos && (pActDivPos < pDivPos))
          pDivPos = pActDivPos;
      }
      if (ArgCnt >= ArgCntMax)
      {
        WrError(ErrNum_TooManyArgs);
        break;
      }
      IncArgCnt();
      ArgStr[ArgCnt].Pos.Len = strmemcpy(ArgStr[ArgCnt].Str, STRINGSIZE, pRun, pDivPos - pRun);
      ArgStr[ArgCnt].Pos.StartCol = ArgPart.Pos.StartCol + (pRun - ArgPart.Str);
      KillPostBlanksStrComp(&ArgStr[ArgCnt]);
      pRun = (pDivPos < pEnd) ? pDivPos + 1 : pEnd;
    }
  }

  Produce_Code();
}

/*------------------------------------------------------------------------*/

static void ProcessFile(String FileName)
{
  long NxtTime, ListTime;
  String Num;
  char *Name, *Run;

  dbgentry("ProcessFile");

  sprintf(OneLine, " INCLUDE \"%s\"", FileName);
  MasterFile = False;
  NextIncDepth = IncDepth;
  SplitLine();
  IncDepth = NextIncDepth;

  ListTime = GTime();

  while ((!InputEnd()) && (!ENDOccured))
  {
    /* Zeile lesen */

    GetNextLine(OneLine);

    /* Ergebnisfelder vorinitialisieren */

    DontPrint = False;
    CodeLen = 0;
    *ListLine = '\0';

    NextDoLst = DoLst;
    NextIncDepth = IncDepth;

    for (Run = OneLine; *Run != '\0'; Run++)
      if (!isspace(((unsigned int) * Run) & 0xff))
        break;
    if (*Run == '#')
      Preprocess();
    else
      SplitLine();

    MakeList();
    DoLst = NextDoLst;
    IncDepth = NextIncDepth;

    /* Zeilenzaehler */

    if (!QuietMode)
    {
      NxtTime = GTime();
      if (((!ListToStdout) || ((ListMask&1) == 0)) && (DTime(ListTime, NxtTime) > 50))
      {
        sprintf(Num, LongIntFormat, MomLineCounter);
        Name = NamePart(CurrFileName);
        printf("%s(%s)%s", Name, Num, ClrEol);
        /*for (z = 0; z < strlen(Name) + strlen(Num) + 2; z++) putchar('\b');*/
        putchar('\r');
        fflush(stdout);
        ListTime = NxtTime;
      }
    }

    /* bei Ende Makroprozessor ausraeumen
      OK - das ist eine Hauruckmethode... */

    if (ENDOccured)
      while (FirstInputTag)
        GetNextLine(OneLine);
  }

  while (FirstInputTag)
    GetNextLine(OneLine);

  /* irgendeine Makrodefinition nicht abgeschlossen ? */

  if (FirstOutputTag)
  {
    WrError(FirstOutputTag->OpenErrMsg);
  }

  dbgexit("ProcessFile");
}

/****************************************************************************/

static char *TWrite_Plur(int n)
{
  return (n != 1) ? getmessage(Num_ListPlurName) : "";
}

static void TWrite_RWrite(char *dest, Double r, Byte Stellen)
{
  String s;
  char *pFirst;

  sprintf(s, "%20.*f", Stellen, r);

  for (pFirst = s; *pFirst; pFirst++)
    if (!isspace(*pFirst))
      break;

  strcat(dest, pFirst);
}

static void TWrite(Double DTime, char *dest)
{
  int h;
  String s;

  *dest = '\0';
  h = (int) floor(DTime/3600.0);
  if (h > 0)
  {
    sprintf(s, "%d", h);
    strcat(dest, s);
    strcat(dest, getmessage(Num_ListHourName));
    strcat(dest, TWrite_Plur(h));
    strcat(dest, ", ");
    DTime -= 3600.0 * h;
  }
  h = (int) floor(DTime/60.0);
  if (h > 0)
  {
    sprintf(s, "%d", h);
    strcat(dest, s);
    strcat(dest, getmessage(Num_ListMinuName));
    strcat(dest, TWrite_Plur(h));
    strcat(dest, ", ");
    DTime -= 60.0 * h;
  }
  TWrite_RWrite(dest, DTime, 2);
  strcat(dest, getmessage(Num_ListSecoName));
  if (DTime != 1)
    strcat(dest, getmessage(Num_ListPlurName));
}

/*--------------------------------------------------------------------------*/

static void AssembleFile_InitPass(void)
{
  static char DateS[31], TimeS[31];
  int z;
  String ArchVal;
  tStrComp TmpComp;

  dbgentry("AssembleFile_InitPass");

  FirstInputTag = NULL;
  FirstOutputTag = NULL;

  MomLineCounter = 0;
  MomLocHandle = -1;
  LocHandleCnt = 0;
  SectSymbolCounter = 0;

  SectionStack = NULL;
  FirstIfSave = NULL;
  FirstSaveState = NULL;
  StructStack =
  pInnermostNamedStruct = NULL;
  for (z = 0; z < PCMax; z++)
    pPhaseStacks[z] = NULL;

  InitPass();

  ActPC = SegCode;
  PCs[ActPC] = 0;
  RelSegs = False;
  ENDOccured = False;
  ErrorCount = 0;
  WarnCount = 0;
  LineSum = 0;
  MacLineSum = 0;
  for (z = 1; z <= StructSeg; z++)
  {
    PCsUsed[z] = FALSE;
    Phases[z] = 0;
    InitChunk(SegChunks + z);
  }

  TransTables =
  CurrTransTable = (PTransTable) malloc(sizeof(TTransTable));
  CurrTransTable->Next = NULL;
  CurrTransTable->Name = as_strdup("STANDARD");
  CurrTransTable->Table = (unsigned char *) malloc(256 * sizeof(char));
  for (z = 0; z < 256; z++)
    CurrTransTable->Table[z] = z;

  EnumSegment = SegNone;
  EnumIncrement = 1;
  EnumCurrentValue = 0;

  strmaxcpy(CurrFileName, "INTERNAL", STRINGSIZE);
  AddFile(CurrFileName);
  CurrLine = 0;

  IncDepth = -1;
  DoLst = eLstMacroExpAll;

  /* Pseudovariablen initialisieren */

  ResetSymbolDefines();
  ResetMacroDefines();
  ResetStructDefines();
  StrCompMkTemp(&TmpComp, FlagTrueName); EnterIntSymbol(&TmpComp, 1, 0, True);
  StrCompMkTemp(&TmpComp, FlagFalseName); EnterIntSymbol(&TmpComp, 0, 0, True);
  StrCompMkTemp(&TmpComp, PiName); EnterFloatSymbol(&TmpComp, 4.0 * atan(1.0), True);
  StrCompMkTemp(&TmpComp, VerName); EnterIntSymbol(&TmpComp, VerNo, 0, True);
  sprintf(ArchVal, "%s-%s", ARCHPRNAME, ARCHSYSNAME);
  StrCompMkTemp(&TmpComp, ArchName); EnterStringSymbol(&TmpComp, ArchVal, True);
  StrCompMkTemp(&TmpComp, Has64Name);
#ifdef HAS64
  EnterIntSymbol(&TmpComp, 1, 0, True);
#else
  EnterIntSymbol(&TmpComp, 0, 0, True);
#endif
  StrCompMkTemp(&TmpComp, CaseSensName); EnterIntSymbol(&TmpComp, Ord(CaseSensitive), 0, True);
  if (PassNo == 0)
  {
    NLS_CurrDateString(DateS);
    NLS_CurrTimeString(False, TimeS);
  }
  if (!FindDefSymbol(DateName))
  {
    StrCompMkTemp(&TmpComp, DateName);
    EnterStringSymbol(&TmpComp, DateS, True);
  }
  if (!FindDefSymbol(TimeName))
  {
    StrCompMkTemp(&TmpComp, TimeName);
    EnterStringSymbol(&TmpComp, TimeS, True);
  }

  SetFlag(&DoPadding, DoPaddingName, True);

  if (*DefCPU == '\0')
    SetCPU(0, True);
  else
  {
    if (!SetNCPU(DefCPU, True))
      SetCPU(0, True);
  }

  SetFlag(&SupAllowed, SupAllowedName, False);
  SetFlag(&FPUAvail, FPUAvailName, False);
  SetFlag(&Maximum, MaximumName, False);
  SetFlag(&DoBranchExt, BranchExtName, False);
  StrCompMkTemp(&TmpComp, ListOnName); EnterIntSymbol(&TmpComp, ListOn = 1, SegNone, True);
  SetLstMacroExp(eLstMacroExpAll);
  InitLstMacroExpMod(&LstMacroExpOverride);
  SetFlag(&RelaxedMode, RelaxedName, False);
  StrCompMkTemp(&TmpComp, NestMaxName); EnterIntSymbol(&TmpComp, NestMax = DEF_NESTMAX, SegNone, True);
  CopyDefSymbols();

  /* initialize counter for temp symbols here after implicit symbols
     have been defined, so counter starts at a value as low as possible */

  InitTmpSymbols();

  ResetPageCounter();

  StartAdrPresent = False;

  AfterBSRAddr = 0;

  Repass = False;
  PassNo++;

#ifdef PROFILE_MEMO
  NumMemoSum = 0;
  NumMemoCnt = 0;
#endif

  dbgexit("AssembleFile_InitPass");
}

static void AssembleFile_ExitPass(void)
{
  tSavePhase *pSavePhase;
  int z;

  SwitchFrom();
  ClearLocStack();
  ClearStacks();
  for (z = 0; z < PCMax; z++)
    while (pPhaseStacks[z])
    {
      pSavePhase = pPhaseStacks[z];
      pPhaseStacks[z] = pSavePhase->pNext;
      free(pSavePhase);
    }
  TossRegDefs(-1);
  if (FirstIfSave)
    WrError(ErrNum_MissEndif);
  if (FirstSaveState)
    WrError(ErrNum_NoRestoreFrame);
  if (SectionStack)
    WrError(ErrNum_MissingEndSect);
  if (StructStack)
    WrXError(ErrNum_OpenStruct, StructStack->Name);
}

static void AssembleFile(char *Name)
{
  String s, Tmp;

  dbgentry("AssembleFile");

  strmaxcpy(SourceFile, Name, STRINGSIZE);
  if (MakeDebug)
    fprintf(Debug, "File %s\n", SourceFile);

  /* Untermodule initialisieren */

  AsmDefInit();
  AsmParsInit();
  AsmIFInit();
  InitFileList();
  ResetStack();

  /* Kommandozeilenoptionen verarbeiten */

  strmaxcpy(OutName, GetFromOutList(), STRINGSIZE);
  if (OutName[0] == '\0')
  {
    strmaxcpy(OutName, SourceFile, STRINGSIZE);
    KillSuffix(OutName);
    AddSuffix(OutName, PrgSuffix);
  }

  if (*ErrorPath == '\0')
  {
    strmaxcpy(ErrorName, SourceFile, STRINGSIZE);
    KillSuffix(ErrorName);
    AddSuffix(ErrorName, LogSuffix);
    unlink(ErrorName);
  }

  switch (ListMode)
  {
    case 0:
      strmaxcpy(LstName, NULLDEV, STRINGSIZE);
      break;
    case 1:
      strmaxcpy(LstName, "!1", STRINGSIZE);
      break;
    case 2:
      strmaxcpy(LstName, GetFromListOutList(), STRINGSIZE);
      if (*LstName == '\0')
      {
        strmaxcpy(LstName, SourceFile, STRINGSIZE);
        KillSuffix(LstName);
        AddSuffix(LstName, LstSuffix);
      }
      break;
  }
  ListToStdout = !strcmp(LstName, "!1");
  ListToNull = !strcmp(LstName, NULLDEV);

  if (ShareMode != 0)
  {
    strmaxcpy(ShareName, GetFromShareOutList(), STRINGSIZE);
    if (*ShareName == '\0')
    {
      strmaxcpy(ShareName, SourceFile, STRINGSIZE);
      KillSuffix(ShareName);
      switch (ShareMode)
      {
        case 1:
          AddSuffix(ShareName, ".inc");
          break;
        case 2:
          AddSuffix(ShareName, ".h");
          break;
        case 3:
          AddSuffix(ShareName, IncSuffix);
          break;
      }
    }
  }

  if (MacProOutput)
  {
    strmaxcpy(MacProName, SourceFile, STRINGSIZE);
    KillSuffix(MacProName);
    AddSuffix(MacProName, PreSuffix);
  }

  if (MacroOutput)
  {
    strmaxcpy(MacroName, SourceFile, STRINGSIZE);
    KillSuffix(MacroName);
    AddSuffix(MacroName, MacSuffix);
  }

  ClearIncludeList();

  if (DebugMode != DebugNone)
    InitLineInfo();

  /* Variablen initialisieren */

  StartTime = GTime();

  PassNo = 0;
  MomLineCounter = 0;

  /* Listdatei eroeffnen */

  if (!QuietMode)
    printf("%s%s\n", getmessage(Num_InfoMessAssembling), SourceFile);

  do
  {
    /* Durchlauf initialisieren */

    AssembleFile_InitPass();
    AsmSubInit();
    if (!QuietMode)
    {
      sprintf(Tmp, IntegerFormat, PassNo);
      printf("%s%s%s\n", getmessage(Num_InfoMessPass), Tmp, ClrEol);
    }

    /* Dateien oeffnen */

    if (CodeOutput)
      OpenFile();

    if (ShareMode != 0)
    {
      ShareFile = fopen(ShareName, "w");
      if (!ShareFile)
        ChkIO(ErrNum_OpeningFile);
      errno = 0;
      switch (ShareMode)
      {
        case 1:
          fprintf(ShareFile, "(* %s-Includefile f%sr CONST-Sektion *)\n", SourceFile, CH_ue);
          break;
        case 2:
          fprintf(ShareFile, "/* %s-Includefile f%sr C-Programm */\n", SourceFile, CH_ue);
          break;
        case 3:
          fprintf(ShareFile, "; %s-Includefile f%sr Assembler-Programm\n", SourceFile, CH_ue);
          break;
      }
      ChkIO(ErrNum_ListWrError);
    }

    if (MacProOutput)
    {
      MacProFile = fopen(MacProName, "w");
      if (!MacProFile)
        ChkIO(ErrNum_OpeningFile);
    }

    if ((MacroOutput) && (PassNo == 1))
    {
      MacroFile = fopen(MacroName, "w");
      if (!MacroFile)
        ChkIO(ErrNum_OpeningFile);
    }

    /* Listdatei oeffnen */

    RewriteStandard(&LstFile, LstName);
    if (!LstFile)
      ChkIO(ErrNum_OpeningFile);
    if (!ListToNull)
    {
      errno = 0;
      fprintf(LstFile, "%s", PrtInitString);
      ChkIO(ErrNum_ListWrError);
    }
    if ((ListMask & 1) != 0)
      NewPage(0, False);

    /* assemblieren */

    ProcessFile(SourceFile);
    AssembleFile_ExitPass();

    /* Dateien schliessen */

    if (CodeOutput)
      CloseFile();

    if (ShareMode != 0)
    {
      errno = 0;
      switch (ShareMode)
      {
        case 1:
          fprintf(ShareFile, "(* Ende Includefile f%sr CONST-Sektion *)\n", CH_ue);
          break;
        case 2:
          fprintf(ShareFile, "/* Ende Includefile f%sr C-Programm */\n", CH_ue);
          break;
        case 3:
          fprintf(ShareFile, "; Ende Includefile f%sr Assembler-Programm\n", CH_ue);
          break;
      }
      ChkIO(ErrNum_ListWrError);
      CloseIfOpen(&ShareFile);
    }

    if (MacProOutput)
      CloseIfOpen(&MacProFile);
    if (MacroOutput && (PassNo == 1))
      CloseIfOpen(&MacroFile);

    /* evtl. fuer naechsten Durchlauf aufraeumen */

    if ((ErrorCount == 0) && (Repass))
    {
      fclose(LstFile);
      if (CodeOutput)
        unlink(OutName);
      CleanupRegDefs();
      ClearCodepages();
      if (MakeUseList)
        ClearUseList();
      if (MakeCrossList)
        ClearCrossList();
      ClearDefineList();
      if (DebugMode != DebugNone)
        ClearLineInfo();
      ClearIncludeList();
      if (DebugMode != DebugNone)
      {
        ResetAddressRanges();
        ClearSectionUsage();
      }
    }
  }
  while ((ErrorCount == 0) && (Repass));

  /* bei Fehlern loeschen */

  if (ErrorCount != 0)
  {
    if (CodeOutput)
      unlink(OutName);
    if (MacProOutput)
      unlink(MacProName);
    if ((MacroOutput) && (PassNo == 1))
      unlink(MacroName);
    if (ShareMode != 0)
      unlink(ShareName);
    GlobErrFlag = True;
  }

  /* Debug-Ausgabe muss VOR die Symbollistenausgabe, weil letztere die
     Symbolliste loescht */

  if (DebugMode != DebugNone)
  {
    if (ErrorCount == 0)
      DumpDebugInfo();
    ClearLineInfo();
  }

  /* Listdatei abschliessen */

  if  (strcmp(LstName, NULLDEV))
  {
    if (ListMask & 2)
      PrintSymbolList();

    if (ListMask & 64)
      PrintRegDefs();

    if (ListMask & 4)
      PrintMacroList();

    if (ListMask & 256)
      PrintStructList();

    if (ListMask & 8)
      PrintFunctionList();

    if (ListMask & 32)
      PrintDefineList();

    if (ListMask & 128)
      PrintCodepages();

    if (MakeUseList)
    {
      NewPage(ChapDepth, True);
      PrintUseList();
    }

    if (MakeCrossList)
    {
      NewPage(ChapDepth, True);
      PrintCrossList();
    }

    if (MakeSectionList)
      PrintSectionList();

    if (MakeIncludeList)
      PrintIncludeList();

    if (!ListToNull)
    {
      errno = 0;
      fprintf(LstFile, "%s", PrtExitString);
      ChkIO(ErrNum_ListWrError);
    }
  }

  if (MakeUseList)
    ClearUseList();

  if (MakeCrossList)
    ClearCrossList();

  ClearSectionList();

  ClearIncludeList();

  if (!*ErrorPath)
    CloseIfOpen(&ErrorFile);

  ClearUp();

  /* Statistik ausgeben */

  StopTime = GTime();
  TWrite(DTime(StartTime, StopTime)/100.0, s);
  if (!QuietMode)
    printf("\n%s%s%s\n\n", s, getmessage(Num_InfoMessAssTime), ClrEol);
  if (ListMode == 2)
  {
    WrLstLine("");
    strmaxcat(s, getmessage(Num_InfoMessAssTime), STRINGSIZE);
    WrLstLine(s);
    WrLstLine("");
  }

  Dec32BlankString(s, LineSum, 7);
  strmaxcat(s, getmessage((LineSum == 1) ? Num_InfoMessAssLine : Num_InfoMessAssLines), STRINGSIZE);
  if (!QuietMode)
    printf("%s%s\n", s, ClrEol);
  if (ListMode == 2)
    WrLstLine(s);

  if (LineSum != MacLineSum)
  {
    Dec32BlankString(s, MacLineSum, 7);
    strmaxcat(s, getmessage((MacLineSum == 1) ? Num_InfoMessMacAssLine : Num_InfoMessMacAssLines), STRINGSIZE);
    if (!QuietMode)
      printf("%s%s\n", s, ClrEol);
    if (ListMode == 2)
      WrLstLine(s);
  }

  Dec32BlankString(s, PassNo, 7);
  strmaxcat(s, getmessage((PassNo == 1) ? Num_InfoMessPassCnt : Num_InfoMessPPassCnt), STRINGSIZE);
  if (!QuietMode)
    printf("%s%s\n", s, ClrEol);
  if (ListMode == 2)
    WrLstLine(s);

  if ((ErrorCount > 0) && (Repass) && (ListMode != 0))
    WrLstLine(getmessage(Num_InfoMessNoPass));

#ifdef __TURBOC__
  sprintf(s, "%s%s", Dec32BlankString(Tmp, coreleft() >> 10, 7), getmessage(Num_InfoMessRemainMem));
  if (!QuietMode)
    printf("%s%s\n", s, ClrEol);
  if (ListMode == 2)
    WrLstLine(s);

  sprintf(s, "%s%s", Dec32BlankString(Tmp, StackRes(), 7), getmessage(Num_InfoMessRemainStack));
  if (!QuietMode)
    printf("%s%s\n", s, ClrEol);
  if (ListMode == 2)
    WrLstLine(s);
#endif

  sprintf(s, "%s%s", Dec32BlankString(Tmp, ErrorCount, 7), getmessage(Num_InfoMessErrCnt));
  if (ErrorCount != 1)
    strmaxcat(s, getmessage(Num_InfoMessErrPCnt), STRINGSIZE);
  if (!QuietMode)
    printf("%s%s\n", s, ClrEol);
  if (ListMode == 2)
    WrLstLine(s);

  sprintf(s, "%s%s", Dec32BlankString(Tmp, WarnCount, 7), getmessage(Num_InfoMessWarnCnt));
  if (WarnCount != 1)
    strmaxcat(s, getmessage(Num_InfoMessWarnPCnt), STRINGSIZE);
  if (!QuietMode)
    printf("%s%s\n", s, ClrEol);
  if (ListMode == 2)
    WrLstLine(s);

#ifdef PROFILE_MEMO
  sprintf(s, "%7.2f%s", ((double)NumMemoSum) / NumMemoCnt, " oppart compares");
  if (!QuietMode)
    printf("%s%s\n", s, ClrEol);
  if (ListMode == 2)
    WrLstLine(s);
#endif

  CloseIfOpen(&LstFile);

  /* verstecktes */

  if (MakeDebug)
    PrintSymbolDepth();

  /* Speicher freigeben */

  ClearSymbolList();
  ClearRegDefs();
  ClearCodepages();
  ClearMacroList();
  ClearFunctionList();
  ClearDefineList();
  ClearFileList();
  ClearStructList();

  dbgentry("AssembleFile");
}

static void AssembleGroup(void)
{
  AddSuffix(FileMask, SrcSuffix);
  if (!DirScan(FileMask, AssembleFile))
    fprintf(stderr, "%s%s\n", FileMask, getmessage(Num_InfoMessNFilesFound));
}

/*-------------------------------------------------------------------------*/

static CMDResult CMD_SharePascal(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  if (!Negate)
    ShareMode = 1;
  else if (ShareMode == 1)
    ShareMode = 0;
  return CMDOK;
}

static CMDResult CMD_ShareC(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  if (!Negate)
    ShareMode = 2;
  else if (ShareMode == 2)
    ShareMode = 0;
  return CMDOK;
}

static CMDResult CMD_ShareAssembler(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  if (!Negate)
    ShareMode = 3;
  else if (ShareMode == 3)
    ShareMode = 0;
  return CMDOK;
}

static CMDResult CMD_DebugMode(Boolean Negate, const char *pArg)
{
  String Arg;

  strmaxcpy(Arg, pArg, STRINGSIZE);
  UpString(Arg);

  if (Negate)
  {
    if (Arg[0] != '\0')
      return CMDErr;
    else
    {
      DebugMode = DebugNone;
      return CMDOK;
    }
  }
  else if (!strcmp(Arg, ""))
  {
    DebugMode = DebugMAP;
    return CMDOK;
  }
  else if (!strcmp(Arg, "ATMEL"))
  {
    DebugMode = DebugAtmel;
    return CMDArg;
  }
  else if (!strcmp(Arg, "MAP"))
  {
    DebugMode = DebugMAP;
    return CMDArg;
  }
  else if (!strcmp(Arg, "NOICE"))
  {
    DebugMode = DebugNoICE;
    return CMDArg;
  }
#if 0
  else if (!strcmp(Arg, "A.OUT"))
  {
    DebugMode = DebugAOUT;
    return CMDArg;
  }
  else if (!strcmp(Arg, "COFF"))
  {
    DebugMode = DebugCOFF;
    return CMDArg;
  }
  else if (!strcmp(Arg, "ELF"))
  {
    DebugMode = DebugELF;
    return CMDArg;
  }
#endif
  else
    return CMDErr;

#if 0
  if (Negate)
    DebugMode = DebugNone;
  else
    DebugMode = DebugMAP;
  return CMDOK;
#endif
}

static CMDResult CMD_ListConsole(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  if (!Negate)
    ListMode = 1;
  else if (ListMode == 1)
    ListMode = 0;
  return CMDOK;
}

static CMDResult CMD_ListFile(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  if (!Negate)
    ListMode = 2;
  else if (ListMode == 2)
    ListMode = 0;
  return CMDOK;
}

static CMDResult CMD_SuppWarns(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  SuppWarns = !Negate;
  return CMDOK;
}

static CMDResult CMD_UseList(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  MakeUseList = !Negate;
  return CMDOK;
}

static CMDResult CMD_CrossList(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  MakeCrossList = !Negate;
  return CMDOK;
}

static CMDResult CMD_SectionList(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  MakeSectionList = !Negate;
  return CMDOK;
}

static CMDResult CMD_BalanceTree(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  BalanceTrees = !Negate;
  return CMDOK;
}

static CMDResult CMD_MakeDebug(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  if (!Negate)
  {
    MakeDebug = True;
    errno = 0;
    Debug = fopen("as.deb", "w");
    if (!Debug)
      ChkIO(ErrNum_ListWrError);
  }
  else if (MakeDebug)
  {
    MakeDebug = False;
    CloseIfOpen(&Debug);
  }
  return CMDOK;
}

static CMDResult CMD_MacProOutput(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  MacProOutput = !Negate;
  return CMDOK;
}

static CMDResult CMD_MacroOutput(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  MacroOutput = !Negate;
  return CMDOK;
}

static CMDResult CMD_MakeIncludeList(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  MakeIncludeList = !Negate;
  return CMDOK;
}

static CMDResult CMD_CodeOutput(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  CodeOutput = !Negate;
  return CMDOK;
}

static CMDResult CMD_MsgIfRepass(Boolean Negate, const char *Arg)
{
  Boolean OK;
  UNUSED(Arg);

  MsgIfRepass = !Negate;
  if (MsgIfRepass)
  {
    if (Arg[0] == '\0')
    {
      PassNoForMessage = 1;
      return CMDOK;
    }
    else
    {
      PassNoForMessage = ConstLongInt(Arg, &OK, 10);
      if (!OK)
      {
        PassNoForMessage = 1;
        return CMDOK;
      }
      else if (PassNoForMessage < 1)
        return CMDErr;
      else
        return CMDArg;
    }
  }
  else
    return CMDOK;
}

static CMDResult CMD_ExtendErrors(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  if ((Negate) && (ExtendErrors > 0))
    ExtendErrors--;
  else if ((!Negate) && (ExtendErrors < 2))
    ExtendErrors++;

  return CMDOK;
}

static CMDResult CMD_NumericErrors(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  NumericErrors = !Negate;
  return CMDOK;
}

static CMDResult CMD_HexLowerCase(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  HexLowerCase = !Negate;
  return CMDOK;
}

static CMDResult CMD_QuietMode(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  QuietMode = !Negate;
  return CMDOK;
}

static CMDResult CMD_ThrowErrors(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  ThrowErrors = !Negate;
  return CMDOK;
}

static CMDResult CMD_CaseSensitive(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  CaseSensitive = !Negate;
  return CMDOK;
}

static CMDResult CMD_GNUErrors(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  GNUErrors  =  !Negate;
  return CMDOK;
}

static CMDResult CMD_IncludeList(Boolean Negate, const char *Arg)
{
  char *p;
  String Copy, part;

  if (*Arg == '\0') return CMDErr;
  else
  {
    strmaxcpy(Copy, Arg, STRINGSIZE);
    do
    {
      p = strrchr(Copy, DIRSEP);
      if (!p)
      {
        strmaxcpy(part, Copy, STRINGSIZE);
        *Copy = '\0';
      }
      else
      {
        *p = '\0';
        strmaxcpy(part, p + 1, STRINGSIZE);
      }
      if (Negate)
        RemoveIncludeList(part);
      else
        AddIncludeList(part);
    }
    while (Copy[0] != '\0');
    return CMDArg;
  }
}

static CMDResult CMD_ListMask(Boolean Negate, const char *Arg)
{
  Word erg;
  Boolean OK;

  if (Arg[0] == '\0')
    return CMDErr;
  else
  {
    erg = ConstLongInt(Arg, &OK, 10);
    if ((!OK) || (erg > 511))
      return CMDErr;
    else
    {
      ListMask = Negate ? (ListMask & ~erg) : (ListMask | erg);
      return CMDArg;
    }
  }
}

static CMDResult CMD_DefSymbol(Boolean Negate, const char *Arg)
{
  String Copy, Part, Name;
  char *p;
  TempResult t;

  if (Arg[0] == '\0')
    return CMDErr;

  strmaxcpy(Copy, Arg, STRINGSIZE);
  do
  {
    p = QuotPos(Copy, ',');
    if (!p)
    {
      strmaxcpy(Part, Copy, STRINGSIZE);
      Copy[0] = '\0';
    }
    else
    {
      *p = '\0';
      strmaxcpy(Part, Copy, STRINGSIZE);
      strmov(Copy, p + 1);
    }
   if (!CaseSensitive)
     UpString(Part);
   p = QuotPos(Part, '=');
   if (!p)
   {
     strmaxcpy(Name, Part, STRINGSIZE);
     Part[0] = '\0';
   }
   else
   {
     *p = '\0';
     strmaxcpy(Name, Part, STRINGSIZE);
     strmov(Part, p + 1);
   }
   if (!ChkSymbName(Name))
     return CMDErr;
   if (Negate)
     RemoveDefSymbol(Name);
   else
   {
     AsmParsInit();
     if (Part[0] != '\0')
     {
       FirstPassUnknown = False;
       EvalExpression(Part, &t);
       if ((t.Typ == TempNone) || (FirstPassUnknown))
         return CMDErr;
     }
     else
     {
       t.Typ = TempInt;
       t.Contents.Int = 1;
     }
     AddDefSymbol(Name, &t);
   }
  }
  while (Copy[0] != '\0');

  return CMDArg;
}

static CMDResult CMD_ErrorPath(Boolean Negate, const char *Arg)
{
  if (Negate)
    return CMDErr;
  else if (Arg[0] == '\0')
  {
    ErrorPath[0] = '\0';
    return CMDOK;
  }
  else
  {
    strmaxcpy(ErrorPath, Arg, STRINGSIZE);
    return CMDArg;
  }
}

static CMDResult CMD_HardRanges(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  HardRanges = Negate;
  return CMDOK;
}

static CMDResult CMD_OutFile(Boolean Negate, const char *Arg)
{
  if (Arg[0] == '\0')
  {
    if (Negate)
    {
      ClearOutList();
      return CMDOK;
    }
    else
      return CMDErr;
  }
  else
  {
    if (Negate)
      RemoveFromOutList(Arg);
    else
      AddToOutList(Arg);
    return CMDArg;
  }
}

static CMDResult CMD_ShareOutFile(Boolean Negate, const char *Arg)
{
  if (Arg[0] == '\0')
  {
    if (Negate)
    {
      ClearShareOutList();
      return CMDOK;
    }
    else
      return CMDErr;
  }
  else
  {
    if (Negate)
      RemoveFromShareOutList(Arg);
    else
      AddToShareOutList(Arg);
    return CMDArg;
  }
}

static CMDResult CMD_ListOutFile(Boolean Negate, const char *Arg)
{
  if (Arg[0] == '\0')
  {
    if (Negate)
    {
      ClearListOutList();
      return CMDOK;
    }
    else
      return CMDErr;
  }
  else
  {
    if (Negate)
      RemoveFromListOutList(Arg);
    else
      AddToListOutList(Arg);
    return CMDArg;
  }
}

static Boolean CMD_CPUAlias_ChkCPUName(char *s)
{
  int z;

  for (z = 0; z < (int)strlen(s); z++)
    if (!isalnum((unsigned int) s[z]))
      return False;
  return True;
}

static CMDResult CMD_CPUAlias(Boolean Negate, const char *Arg)
{
  char *p;
  String s1, s2;

  if (Negate)
    return CMDErr;
  else if (Arg[0] == '\0')
    return CMDErr;
  else
  {
    p = strchr(Arg, '=');
    if (!p)
      return CMDErr;
    else
    {
      *p = '\0';
      strmaxcpy(s1, Arg, STRINGSIZE);
      UpString(s1);
      strmaxcpy(s2, p + 1, STRINGSIZE);
      UpString(s2);
      *p = '=';
      if (!(CMD_CPUAlias_ChkCPUName(s1) && CMD_CPUAlias_ChkCPUName(s2)))
        return CMDErr;
      else if (!AddCPUAlias(s2, s1))
        return CMDErr;
      else
        return CMDArg;
    }
  }
}

static CMDResult CMD_SetCPU(Boolean Negate, const char *Arg)
{
  if (Negate)
  {
    *DefCPU = '\0';
    return CMDOK;
  }
  else
  {
    if (*Arg == '\0')
      return CMDErr;

    strmaxcpy(DefCPU, Arg, sizeof(DefCPU) - 1);
    NLS_UpString(DefCPU);

    if (!LookupCPUDefByName(DefCPU))
    {
      *DefCPU = '\0';
      return CMDErr;
    }
    return CMDArg;
  }
}

static CMDResult CMD_NoICEMask(Boolean Negate, const char *Arg)
{
  Word erg;
  Boolean OK;

  if (Negate)
  {
    NoICEMask = 1 << SegCode;
    return CMDOK;
  }
  else if (Arg[0] == '\0')
    return CMDErr;
  else
  {
    erg = ConstLongInt(Arg, &OK, 10);
    if ((!OK) || (erg > (1 << PCMax)))
      return CMDErr;
    else
    {
      NoICEMask = erg;
      return CMDArg;
    }
  }
}

static CMDResult CMD_MaxErrors(Boolean Negate, const char *Arg)
{
  if (Negate)
  {
    MaxErrors = 0;
    return CMDOK;
  }
  else if (Arg[0] == '\0')
    return CMDErr;
  else
  {
    Boolean OK;
    LongWord NewMaxErrors = ConstLongInt(Arg, &OK, 10);

    if (!OK)
      return CMDErr;
    MaxErrors = NewMaxErrors;
    return CMDArg;
  }
}

static CMDResult CMD_TreatWarningsAsErrors(Boolean Negate, const char *Arg)
{
  UNUSED(Arg);

  TreatWarningsAsErrors = !Negate;
  return CMDOK;
}

static void ParamError(Boolean InEnv, char *Arg)
{
  printf("%s%s\n", getmessage((InEnv) ? Num_ErrMsgInvEnvParam : Num_ErrMsgInvParam), Arg);
  exit(4);
}

#define ASParamCnt (sizeof(ASParams) / sizeof(*ASParams))

static CMDRec ASParams[] =
{
  { "A"             , CMD_BalanceTree     },
  { "ALIAS"         , CMD_CPUAlias        },
  { "a"             , CMD_ShareAssembler  },
  { "C"             , CMD_CrossList       },
  { "c"             , CMD_ShareC          },
  { "CPU"           , CMD_SetCPU          },
  { "D"             , CMD_DefSymbol       },
  { "E"             , CMD_ErrorPath       },
  { "g"             , CMD_DebugMode       },
  { "G"             , CMD_CodeOutput      },
  { "GNUERRORS"     , CMD_GNUErrors       },
  { "h"             , CMD_HexLowerCase    },
  { "i"             , CMD_IncludeList     },
  { "I"             , CMD_MakeIncludeList },
  { "L"             , CMD_ListFile        },
  { "l"             , CMD_ListConsole     },
  { "M"             , CMD_MacroOutput     },
  { "MAXERRORS"     , CMD_MaxErrors       },
  { "n"             , CMD_NumericErrors   },
  { "NOICEMASK"     , CMD_NoICEMask       },
  { "o"             , CMD_OutFile         },
  { "P"             , CMD_MacProOutput    },
  { "p"             , CMD_SharePascal     },
  { "q"             , CMD_QuietMode       },
  { "QUIET"         , CMD_QuietMode       },
  { "r"             , CMD_MsgIfRepass     },
  { "s"             , CMD_SectionList     },
  { "SHAREOUT"      , CMD_ShareOutFile    },
  { "OLIST"         , CMD_ListOutFile     },
  { "t"             , CMD_ListMask        },
  { "u"             , CMD_UseList         },
  { "U"             , CMD_CaseSensitive   },
  { "w"             , CMD_SuppWarns       },
  { "WARNRANGES"    , CMD_HardRanges      },
  { "WERROR"        , CMD_TreatWarningsAsErrors },
  { "x"             , CMD_ExtendErrors    },
  { "X"             , CMD_MakeDebug       },
  { "Y"             , CMD_ThrowErrors     }
};

/*--------------------------------------------------------------------------*/

#ifdef __sunos__

extern void on_exit(void (*procp)(int status, caddr_t arg),caddr_t arg);

static void GlobExitProc(int status, caddr_t arg)
{
  if (MakeDebug)
    CloseIfOpen(&Debug);
}

#else

static void GlobExitProc(void)
{
  if (MakeDebug)
    CloseIfOpen(&Debug);
}

#endif

static int LineZ;

static void NxtLine(void)
{
  if (++LineZ == 23)
  {
    LineZ = 0;
    if (Redirected != NoRedir)
      return;
    printf("%s", getmessage(Num_KeyWaitMsg));
    fflush(stdout);
    while (getchar() != '\n');
    printf("%s%s", CursUp, ClrEol);
  }
}

static void WrHead(void)
{
  if (!QuietMode)
  {
    printf("%s%s\n", getmessage(Num_InfoMessMacroAss), Version);
    NxtLine();
    printf("(%s-%s)\n", ARCHPRNAME, ARCHSYSNAME);
    NxtLine();
    printf("%s\n", InfoMessCopyright);
    NxtLine();
    WriteCopyrights(NxtLine);
    printf("\n");
    NxtLine();
  }
}

int main(int argc, char **argv)
{
  char *Env, *ph1, *ph2;
  String Dummy;
  static Boolean First = TRUE;
  CMDProcessed ParUnprocessed;     /* bearbeitete Kommandozeilenparameter */

  FileMask = (char*)malloc(sizeof(char) * STRINGSIZE);

  ParamCount = argc - 1;
  ParamStr = argv;

  if (First)
  {
    endian_init();
    nls_init();
    bpemu_init();
    stdhandl_init();
    strutil_init();
    chunks_init();
    NLS_Initialize();

    nlmessages_init("as.msg", *argv, MsgId1, MsgId2);
    ioerrs_init(*argv);
    cmdarg_init(*argv);

    asmfnums_init();
    asminclist_init();
    asmitree_init();

    asmdef_init();
    cpulist_init();
    asmsub_init();
    asmpars_init();

    asmmac_init();
    asmstruct_init();
    asmif_init();
    asmcode_init();
    asmdebug_init();

    codeallg_init();

    code68k_init();
    code56k_init();
    code601_init();
    codemcore_init();
    codexgate_init();
    code68_init();
    code6805_init();
    code6809_init();
    code6812_init();
    codes12z_init();
    code6816_init();
    code68rs08_init();
    codeh8_3_init();
    codeh8_5_init();
    code7000_init();
    code65_init();
    codeh16_init();
    code7700_init();
    codehmcs400_init();
    code4500_init();
    codem16_init();
    codem16c_init();
    code4004_init();
    code8008_init();
    code48_init();
    code51_init();
    code96_init();
    code85_init();
    code86_init();
    code960_init();
    code8x30x_init();
    code2650_init();
    codexa_init();
    codeavr_init();
    code29k_init();
    code166_init();
    codez80_init();
    codez8_init();
    codekcpsm_init();
    codekcpsm3_init();
    codemico8_init();
    code96c141_init();
    code90c141_init();
    code87c800_init();
    code870c_init();
    code47c00_init();
    code97c241_init();
    code9331_init();
    code16c5x_init();
    code16c8x_init();
    code17c4x_init();
    codesx20_init();
    codest6_init();
    codest7_init();
    codest9_init();
    code6804_init();
    code3201x_init();
    code3202x_init();
    code3203x_init();
    code3205x_init();
    code32054x_init();
    code3206x_init();
    code9900_init();
    codetms7_init();
    code370_init();
    codemsp_init();
    codetms1_init();
    code78c10_init();
    code75xx_init();
    code75k0_init();
    code78k0_init();
    code78k2_init();
    code78k3_init();
    code78k4_init();
    code7720_init();
    code77230_init();
    codescmp_init();
    code807x_init();
    codecop4_init();
    codecop8_init();
    codesc14xxx_init();
    codeace_init();
    codef8_init();
    code53c8xx_init();
    codef2mc8_init();
    codef2mc16_init();
    codeolms40_init();
    codeolms50_init();
    code1802_init();
    codevector_init();
    codexcore_init();
    code1750_init();
    First = FALSE;
  }

#ifdef __sunos__
  on_exit(GlobExitProc, (caddr_t) NULL);
#else
# ifndef __MUNIX__
  atexit(GlobExitProc);
# endif
#endif

  *CursUp = '\0';
  *ClrEol = '\0';
  switch (Redirected)
  {
    case NoRedir:
      Env = getenv("USEANSI");
      strmaxcpy(Dummy, Env ? Env : "Y", STRINGSIZE);
      if (mytoupper(Dummy[0]) == 'N')
      {
      }
      else
      {
        strcpy(ClrEol, " [K"); ClrEol[0] = Char_ESC;  /* ANSI-Sequenzen */
        strcpy(CursUp, " [A"); CursUp[0] = Char_ESC;
      }
      break;
    case RedirToDevice:
      /* Basissteuerzeichen fuer Geraete */
      memset(ClrEol, ' ', 20);
      memset(ClrEol + 20, '\b', 20);
      ClrEol[40] = '\0';
      break;
    case RedirToFile:
      strcpy(ClrEol, "\n");  /* CRLF auf Datei */
  }

  ShareMode = 0;
  ListMode = 0;
  IncludeList[0] = '\0';
  SuppWarns = False;
  MakeUseList = False;
  MakeCrossList = False;
  MakeSectionList = False;
  MakeIncludeList = False;
  ListMask = 0x1ff;
  MakeDebug = False;
  ExtendErrors = 0;
  MacroOutput = False;
  MacProOutput = False;
  CodeOutput = True;
  strcpy(ErrorPath,  "!2");
  MsgIfRepass = False;
  QuietMode = False;
  NumericErrors = False;
  DebugMode = DebugNone;
  CaseSensitive = False;
  ThrowErrors = False;
  HardRanges = True;
  NoICEMask = 1 << SegCode;
  GNUErrors = False;
  MaxErrors = 0;
  TreatWarningsAsErrors = False;

  LineZ = 0;

  if (ParamCount == 0)
  {
    WrHead();
    printf("%s%s%s\n", getmessage(Num_InfoMessHead1), GetEXEName(), getmessage(Num_InfoMessHead2));
    NxtLine();
    for (ph1 = getmessage(Num_InfoMessHelp), ph2 = strchr(ph1, '\n'); ph2; ph1 = ph2 + 1, ph2 = strchr(ph1, '\n'))
    {
      *ph2 = '\0';
      printf("%s\n", ph1);
      NxtLine();
      *ph2 = '\n';
    }
    PrintCPUList(NxtLine);
    ClearCPUList();
    exit(1);
  }

#if defined(STDINCLUDES)
  CMD_IncludeList(False, STDINCLUDES);
#endif
  ProcessCMD(ASParams, ASParamCnt, ParUnprocessed, EnvName, ParamError);

  /* wegen QuietMode dahinter */

  WrHead();

  GlobErrFlag = False;
  if (ErrorPath[0] != '\0')
  {
    strcpy(ErrorName, ErrorPath);
    unlink(ErrorName);
  }

  if (StringListEmpty(FileArgList))
  {
    printf("%s [%s] ", getmessage(Num_InvMsgSource), SrcSuffix);
    fflush(stdout);
    if (!fgets(FileMask, STRINGSIZE, stdin))
      return 0;
    if ((*FileMask) && (FileMask[strlen(FileMask) - 1] == '\n'))
      FileMask[strlen(FileMask) - 1] = '\0';
    AssembleGroup();
  }
  else
  {
    StringRecPtr Lauf;
    char *pFile;

    pFile = GetStringListFirst(FileArgList, &Lauf);
    while ((pFile) && (*pFile))
    {
      strmaxcpy(FileMask, pFile, STRINGSIZE);
      AssembleGroup();
      pFile = GetStringListNext(&Lauf);
    }
  }

  if (*ErrorPath)
    CloseIfOpen(&ErrorFile);

  ClearCPUList();

  return GlobErrFlag ? 2 : 0;
}
