/* codekcp3.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator xilinx kcpsm3                                               */
/*                                                                           */
/*****************************************************************************/
/* $Id: codekcp3.h,v 1.1 2005/03/21 19:48:16 alfred Exp $                   */
/*****************************************************************************
 * $Log: codekcp3.h,v $
 * Revision 1.1  2005/03/21 19:48:16  alfred
 * - shortened name to 8+3 (again...)
 *
 * Revision 1.1  2005/02/19 18:05:59  alfred
 * - use shorter name for 8+3 filesystems, correct bugs
 *
 *****************************************************************************/

extern void codekcpsm3_init(void);
