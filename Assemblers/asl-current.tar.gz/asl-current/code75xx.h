#ifndef _CODE75XX_H
#define _CODE75XX_H
/* code75xx.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator NEC 75xx                                                    */
/*                                                                           */
/* Historie: 2013-03-09 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code75xx_init(void);
#endif /* _CODE75XX_H */
